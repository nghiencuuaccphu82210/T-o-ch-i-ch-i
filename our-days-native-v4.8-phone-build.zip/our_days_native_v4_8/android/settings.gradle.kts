pluginManagement {
    val properties = java.util.Properties()
    val local = file("local.properties")
    require(local.exists()) { "Flutter SDK is missing. Run flutter pub get from the project folder first." }
    local.inputStream().use { properties.load(it) }
    val flutterSdkPath = properties.getProperty("flutter.sdk")
        ?: error("flutter.sdk is not set in android/local.properties")
    includeBuild("$flutterSdkPath/packages/flutter_tools/gradle")
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
plugins {
    id("dev.flutter.flutter-plugin-loader") version "1.0.0"
    id("com.android.application") version "8.12.1" apply false
    id("org.jetbrains.kotlin.android") version "2.2.0" apply false
}
include(":app")
