# iOS project generation

The Dart app is configured for iOS 13+. To generate the standard Xcode Runner project files on a Mac with Flutter and Xcode installed, run from the project root:

```bash
flutter create --platforms=ios --org com.ourdays --project-name our_days .
```

Then confirm `ios/Runner/Info.plist` retains the photo-library usage string. Build the IPA on macOS:

```bash
flutter pub get
flutter build ipa --release
```
