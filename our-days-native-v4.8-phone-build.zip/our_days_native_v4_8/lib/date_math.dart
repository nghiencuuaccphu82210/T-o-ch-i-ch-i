/// Calendar/date calculations preserved from Our Days HTML V4.8.
class ElapsedParts {
  const ElapsedParts(this.years, this.months, this.days, this.hours, this.minutes, this.seconds);
  final int years, months, days, hours, minutes, seconds;
}

class AnnualInfo {
  const AnnualInfo({required this.years, required this.percent, required this.daysLeft, required this.periodDays, required this.passedDays});
  final int years, percent, daysLeft, periodDays, passedDays;
}

class BirthdayInfo {
  const BirthdayInfo({required this.age, required this.remaining, required this.progress, required this.nextDate});
  final int age, remaining;
  final double progress;
  final DateTime nextDate;
}

DateTime dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);
DateTime addCalendarYears(DateTime base, int amount) {
  final y = base.year + amount;
  final last = DateTime(y, base.month + 1, 0).day;
  return DateTime(y, base.month, base.day.clamp(1, last).toInt(), base.hour, base.minute, base.second, base.millisecond, base.microsecond);
}
DateTime addCalendarMonths(DateTime base, int amount) {
  final absolute = base.year * 12 + base.month - 1 + amount;
  final y = absolute ~/ 12;
  final m = absolute % 12 + 1;
  final last = DateTime(y, m + 1, 0).day;
  return DateTime(y, m, base.day.clamp(1, last).toInt(), base.hour, base.minute, base.second, base.millisecond, base.microsecond);
}

int currentDays(DateTime start, [DateTime? now]) {
  final today = dateOnly(now ?? DateTime.now());
  final begin = dateOnly(start);
  return today.isBefore(begin) ? 0 : today.difference(begin).inDays + 1;
}

int nextMilestone(int days) {
  const milestones = [7, 14, 30, 50, 100, 200, 300, 365, 500, 730, 1000, 1500, 2000, 3000, 3650];
  for (final n in milestones) { if (n > days) return n; }
  return ((days + 1) / 365).ceil() * 365;
}

ElapsedParts elapsedCalendarParts(DateTime start, DateTime now) {
  if (now.isBefore(start)) return const ElapsedParts(0, 0, 0, 0, 0, 0);
  var years = (now.year - start.year).clamp(0, 10000).toInt();
  while (years > 0 && addCalendarYears(start, years).isAfter(now)) { years--; }
  final yearAnchor = addCalendarYears(start, years);
  var months = ((now.year - yearAnchor.year) * 12 + now.month - yearAnchor.month).clamp(0, 120000).toInt();
  while (months > 0 && addCalendarMonths(yearAnchor, months).isAfter(now)) { months--; }
  final monthAnchor = addCalendarMonths(yearAnchor, months);
  final calendarDays = dateOnly(now).difference(dateOnly(monthAnchor)).inDays.clamp(0, 400000).toInt();
  final dayAnchor = DateTime(monthAnchor.year, monthAnchor.month, monthAnchor.day + calendarDays, monthAnchor.hour, monthAnchor.minute, monthAnchor.second, monthAnchor.millisecond, monthAnchor.microsecond);
  var remaining = now.difference(dayAnchor);
  final hours = remaining.inHours; remaining -= Duration(hours: hours);
  final minutes = remaining.inMinutes; remaining -= Duration(minutes: minutes);
  final seconds = remaining.inSeconds;
  return ElapsedParts(years, months, calendarDays, hours, minutes, seconds);
}

AnnualInfo annualProgressInfo(DateTime start, DateTime now) {
  if (now.isBefore(start)) {
    return AnnualInfo(years: 0, percent: 0, daysLeft: (start.difference(now).inSeconds / 86400).ceil(), periodDays: 365, passedDays: 0);
  }
  var years = (now.year - start.year).clamp(0, 10000).toInt();
  while (years > 0 && addCalendarYears(start, years).isAfter(now)) { years--; }
  final previous = addCalendarYears(start, years);
  final next = addCalendarYears(start, years + 1);
  final total = next.difference(previous).inMilliseconds.clamp(1, 1 << 62).toInt();
  final passed = now.difference(previous).inMilliseconds.clamp(0, total).toInt();
  final percent = (passed / total * 100).floor().clamp(0, 99).toInt();
  return AnnualInfo(
    years: years,
    percent: percent.toInt(),
    daysLeft: (next.difference(now).inSeconds / 86400).ceil().clamp(0, 100000).toInt(),
    periodDays: (total / Duration.millisecondsPerDay).round().clamp(1, 1000).toInt(),
    passedDays: (passed / Duration.millisecondsPerDay).floor().clamp(0, 1000).toInt(),
  );
}

DateTime _birthdayInYear(int year, int month, int day) {
  if (month == 2 && day == 29) {
    final leap = year % 4 == 0 && (year % 100 != 0 || year % 400 == 0);
    if (!leap) return DateTime(year, 3, 1);
  }
  return DateTime(year, month, day);
}

BirthdayInfo? birthdayInfo(DateTime? birth, [DateTime? now]) {
  if (birth == null) return null;
  final today = dateOnly(now ?? DateTime.now());
  var age = today.year - birth.year;
  final thisYear = _birthdayInYear(today.year, birth.month, birth.day);
  if (today.isBefore(thisYear)) age--;
  var next = thisYear;
  if (next.isBefore(today)) next = _birthdayInYear(today.year + 1, birth.month, birth.day);
  final previous = _birthdayInYear(next.year - 1, birth.month, birth.day);
  final total = next.difference(previous).inDays.clamp(1, 366).toInt();
  final passed = today.difference(previous).inDays.clamp(0, total).toInt();
  final remaining = next.difference(today).inDays.clamp(0, 366).toInt();
  return BirthdayInfo(age: age.clamp(0, 150).toInt(), remaining: remaining, progress: remaining == 0 ? 1 : passed / total, nextDate: next);
}


DateTime nextRecurringDate(int month, int day, [DateTime? now]) {
  final today = dateOnly(now ?? DateTime.now());
  var candidate = DateTime(today.year, month, day);
  if (candidate.isBefore(today)) candidate = DateTime(today.year + 1, month, day);
  return candidate;
}

String isoDate(DateTime d) => '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
DateTime? parseDate(dynamic value) {
  if (value is! String || value.isEmpty) return null;
  try {
    final s = value.trim();
    final manual = RegExp(r'^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$').firstMatch(s);
    if (manual != null) {
      final day = int.parse(manual.group(1)!);
      final month = int.parse(manual.group(2)!);
      final year = int.parse(manual.group(3)!);
      final parsed = DateTime(year, month, day);
      if (parsed.year != year || parsed.month != month || parsed.day != day) return null;
      return parsed;
    }
    final parsed = DateTime.tryParse(s);
    if (parsed == null || s.length < 10 || isoDate(parsed) != s.substring(0, 10)) return null;
    return DateTime(parsed.year, parsed.month, parsed.day);
  } catch (_) {
    return null;
  }
}
String formatDate(DateTime d) => '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
String formatNumber(int n) {
  final s = n.toString();
  final b = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write('.');
    b.write(s[i]);
  }
  return b.toString();
}
