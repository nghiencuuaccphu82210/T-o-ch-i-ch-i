import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import 'date_math.dart';

Map<String, dynamic> defaultData() => {
  'personOne': 'Mình', 'personTwo': 'Người ấy', 'startDate': isoDate(DateTime.now()),
  'genderOne': '', 'genderTwo': '', 'birthDateOne': '', 'birthDateTwo': '',
  'avatarOne': '', 'avatarTwo': '', 'background': '',
  'memories': <Map<String, dynamic>>[], 'photos': <Map<String, dynamic>>[],
  'themePalette': 'rose', 'themeMode': 'light', 'themeModeChosen': false,
  'performanceLevel': 'medium', 'motionEnabled': true, 'notificationsEnabled': false,
  'lastNotifiedMilestone': 0, 'lastNotifiedBirthday': {'one': '', 'two': ''},
};

class DataStore extends ChangeNotifier {
  late Directory _root;
  late Directory _images;
  late File _dataFile;
  Map<String, dynamic> data = defaultData();

  Future<void> init() async {
    final base = await getApplicationDocumentsDirectory();
    _root = Directory('${base.path}/our_days');
    _images = Directory('${_root.path}/images');
    await _images.create(recursive: true);
    _dataFile = File('${_root.path}/our_days_data.json');
    if (await _dataFile.exists()) {
      try {
        final decoded = jsonDecode(await _dataFile.readAsString());
        if (decoded is Map) data = _normalise(Map<String, dynamic>.from(decoded));
      } catch (_) { data = defaultData(); }
    }
    await save(notify: false);
  }

  String get rootPath => _root.path;
  File? assetFile(String? path) {
    if (path == null || path.isEmpty || path.startsWith('data:')) return null;
    if (path.startsWith('/')) return File(path);
    return File('${_root.path}/$path');
  }

  String _imageExtension(Uint8List bytes) {
    if (bytes.length >= 8 && bytes[0] == 0x89 && bytes[1] == 0x50 && bytes[2] == 0x4E && bytes[3] == 0x47) return '.png';
    if (bytes.length >= 12 && bytes[0] == 0x52 && bytes[1] == 0x49 && bytes[2] == 0x46 && bytes[3] == 0x46 && bytes[8] == 0x57 && bytes[9] == 0x45 && bytes[10] == 0x42 && bytes[11] == 0x50) return '.webp';
    if (bytes.length >= 4 && bytes[0] == 0x47 && bytes[1] == 0x49 && bytes[2] == 0x46 && bytes[3] == 0x38) return '.gif';
    return '.jpg';
  }

  String _imageMime(String path) {
    final ext = _extension(path);
    return switch (ext) {
      '.png' => 'image/png',
      '.webp' => 'image/webp',
      '.gif' => 'image/gif',
      _ => 'image/jpeg',
    };
  }

  Future<String> saveImageBytes(Uint8List bytes, String prefix) async {
    final safe = prefix.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '_');
    final name = '${safe}_${DateTime.now().microsecondsSinceEpoch}${_imageExtension(bytes)}';
    final file = File('${_images.path}/$name');
    await file.writeAsBytes(bytes, flush: true);
    return 'images/$name';
  }

  Future<String> importAsset(dynamic value, String prefix) async {
    if (value is! String || value.isEmpty) return '';
    if (value.startsWith('data:image/')) {
      final comma = value.indexOf(',');
      if (comma < 0) return '';
      try { return await saveImageBytes(base64Decode(value.substring(comma + 1)), prefix); } catch (_) { return ''; }
    }
    if (value.startsWith('images/')) {
      final existing = assetFile(value);
      if (existing != null && await existing.exists()) return value;
    }
    final source = File(value);
    if (await source.exists()) {
      try {
        final name = '${prefix}_${DateTime.now().microsecondsSinceEpoch}${_extension(source.path)}';
        await source.copy('${_images.path}/$name');
        return 'images/$name';
      } catch (_) { return ''; }
    }
    return '';
  }

  String _extension(String path) {
    final match = RegExp(r'\.(jpg|jpeg|png|webp|gif)$', caseSensitive: false).firstMatch(path);
    return match == null ? '.jpg' : '.${match.group(1)!.toLowerCase()}';
  }

  Map<String, dynamic> _normalise(Map<String, dynamic> source) {
    final d = defaultData();
    d.addAll(source);
    final personOne = (source['personOne'] ?? 'Mình').toString().trim();
    final personTwo = (source['personTwo'] ?? 'Người ấy').toString().trim();
    d['personOne'] = personOne.isEmpty ? 'Mình' : personOne.substring(0, personOne.length.clamp(0, 24).toInt());
    d['personTwo'] = personTwo.isEmpty ? 'Người ấy' : personTwo.substring(0, personTwo.length.clamp(0, 24).toInt());
    d['startDate'] = parseDate(source['startDate']) == null ? isoDate(DateTime.now()) : isoDate(parseDate(source['startDate'])!);
    for (final key in ['birthDateOne', 'birthDateTwo']) {
      final value = parseDate(source[key]);
      d[key] = value == null ? '' : isoDate(value);
    }
    for (final key in ['genderOne', 'genderTwo']) {
      if (!['', 'Nam', 'Nữ', 'Khác'].contains(d[key])) d[key] = '';
    }
    if (!['rose', 'lavender', 'ocean', 'mint', 'sunset'].contains(d['themePalette'])) d['themePalette'] = 'rose';
    d['themeMode'] = source['themeModeChosen'] == true && source['themeMode'] == 'dark' ? 'dark' : 'light';
    if (!['low', 'medium', 'high'].contains(d['performanceLevel'])) d['performanceLevel'] = 'medium';
    d['themeModeChosen'] = source['themeModeChosen'] == true;
    d['motionEnabled'] = source['motionEnabled'] != false;
    d['notificationsEnabled'] = source['notificationsEnabled'] == true;
    final last = source['lastNotifiedBirthday'];
    d['lastNotifiedBirthday'] = {'one': last is Map ? (last['one'] ?? '').toString() : '', 'two': last is Map ? (last['two'] ?? '').toString() : ''};
    d['lastNotifiedMilestone'] = int.tryParse('${source['lastNotifiedMilestone'] ?? 0}') ?? 0;
    d['memories'] = _normaliseItems(source['memories'], isPhoto: false);
    d['photos'] = _normaliseItems(source['photos'], isPhoto: true);
    for (final key in ['avatarOne', 'avatarTwo', 'background']) { d[key] = (source[key] ?? '').toString(); }
    return d;
  }

  List<Map<String, dynamic>> _normaliseItems(dynamic value, {required bool isPhoto}) {
    if (value is! List) return <Map<String, dynamic>>[];
    final result = <Map<String, dynamic>>[];
    for (var i = 0; i < value.length; i++) {
      final item = value[i];
      if (item is! Map) continue;
      final map = Map<String, dynamic>.from(item);
      final date = parseDate(map['date']) ?? DateTime.now();
      if (isPhoto) {
        final src = (map['src'] ?? map['photo'] ?? '').toString();
        if (src.isEmpty) continue;
        result.add({'id': (map['id'] ?? 'photo-$i-${DateTime.now().millisecondsSinceEpoch}').toString(), 'caption': (map['caption'] ?? map['title'] ?? 'Một khoảnh khắc').toString().substring(0, (map['caption'] ?? map['title'] ?? 'Một khoảnh khắc').toString().length.clamp(0, 70).toInt()), 'date': isoDate(date), 'src': src});
      } else {
        final title = (map['title'] ?? 'Kỷ niệm').toString();
        final note = (map['note'] ?? '').toString();
        result.add({'id': (map['id'] ?? 'memory-$i-${DateTime.now().millisecondsSinceEpoch}').toString(), 'title': title.substring(0, title.length.clamp(0, 60).toInt()), 'date': isoDate(date), 'note': note.substring(0, note.length.clamp(0, 260).toInt()), 'photo': (map['photo'] ?? '').toString()});
      }
    }
    return result;
  }

  Future<void> save({bool notify = true}) async {
    await _root.create(recursive: true);
    await _dataFile.writeAsString(jsonEncode(data), flush: true);
    if (notify) notifyListeners();
  }

  Future<Map<String, dynamic>> createBackup() async {
    final copy = jsonDecode(jsonEncode(data)) as Map<String, dynamic>;
    for (final key in ['avatarOne', 'avatarTwo', 'background']) {
      copy[key] = await _assetAsData(copy[key]?.toString() ?? '');
    }
    final memories = (copy['memories'] as List).cast<Map<String, dynamic>>();
    for (final item in memories) { item['photo'] = await _assetAsData(item['photo']?.toString() ?? ''); }
    final photos = (copy['photos'] as List).cast<Map<String, dynamic>>();
    for (final item in photos) { item['src'] = await _assetAsData(item['src']?.toString() ?? ''); }
    return {'app': 'Our Days', 'format': 'our-days-backup', 'schemaVersion': 4, 'exportedAt': DateTime.now().toIso8601String(), 'data': copy};
  }

  Future<String> _assetAsData(String path) async {
    if (path.isEmpty) return '';
    if (path.startsWith('data:image/')) return path;
    final f = assetFile(path);
    if (f == null || !await f.exists()) return '';
    try {
      final bytes = await f.readAsBytes();
      return 'data:${_imageMime(f.path)};base64,${base64Encode(bytes)}';
    } catch (_) {
      return '';
    }
  }

  Future<void> importBackup(Map<String, dynamic> input, {required bool merge}) async {
    Map<String, dynamic> incoming;
    if (input['format'] == 'our-days-backup' && input['data'] is Map) {
      incoming = Map<String, dynamic>.from(input['data'] as Map);
    } else if ((input['type'] == 'our-days-full-backup' || input['app'] == 'Our Days' || input['schemaVersion'] != null) && input['data'] is Map) {
      incoming = Map<String, dynamic>.from(input['data'] as Map);
    } else if (input.containsKey('startDate') || input['memories'] is List || input['photos'] is List) {
      incoming = Map<String, dynamic>.from(input);
    } else { throw const FormatException('Không tìm thấy dữ liệu Our Days trong tệp.'); }

    for (final key in ['avatarOne', 'avatarTwo', 'background']) {
      incoming[key] = await importAsset(incoming[key], 'import_$key');
    }
    final memories = (incoming['memories'] is List ? incoming['memories'] as List : <dynamic>[]).map((e) => e is Map ? Map<String, dynamic>.from(e) : <String, dynamic>{}).toList();
    for (var i = 0; i < memories.length; i++) { memories[i]['photo'] = await importAsset(memories[i]['photo'], 'memory_$i'); }
    incoming['memories'] = memories;
    final photos = (incoming['photos'] is List ? incoming['photos'] as List : <dynamic>[]).map((e) => e is Map ? Map<String, dynamic>.from(e) : <String, dynamic>{}).toList();
    for (var i = 0; i < photos.length; i++) { photos[i]['src'] = await importAsset(photos[i]['src'] ?? photos[i]['photo'], 'photo_$i'); }
    incoming['photos'] = photos;
    final cleaned = _normalise(incoming);
    if (!merge) {
      data = cleaned;
    } else {
      data['memories'] = _mergeItems(data['memories'] as List, cleaned['memories'] as List, 'memory');
      data['photos'] = _mergeItems(data['photos'] as List, cleaned['photos'] as List, 'photo');
      // The existing profile, date and appearance remain unchanged during merge.
    }
    await save();
  }

  List<Map<String, dynamic>> _mergeItems(List existing, List incoming, String type) {
    final result = existing.map((e) => Map<String, dynamic>.from(e as Map)).toList();
    final seen = result.map((e) => '${e['id']}|${e['date']}|${type == 'photo' ? e['src'] : e['title']}').toSet();
    for (final raw in incoming) {
      final e = Map<String, dynamic>.from(raw as Map);
      final key = '${e['id']}|${e['date']}|${type == 'photo' ? e['src'] : e['title']}';
      if (seen.add(key)) result.add(e);
    }
    return result;
  }

  Future<void> clearAll() async {
    data = defaultData();
    if (await _images.exists()) {
      await _images.delete(recursive: true);
    }
    await _images.create(recursive: true);
    await save();
  }
}
