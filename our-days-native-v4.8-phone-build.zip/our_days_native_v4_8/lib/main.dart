import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' show ImageFilter;

import 'package:cross_file/cross_file.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import 'data_store.dart';
import 'date_math.dart';

final FlutterLocalNotificationsPlugin notifications = FlutterLocalNotificationsPlugin();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  const android = AndroidInitializationSettings('ic_stat_our_days');
  const ios = DarwinInitializationSettings(requestAlertPermission: false, requestBadgePermission: false, requestSoundPermission: false);
  await notifications.initialize(settings: const InitializationSettings(android: android, iOS: ios));
  runApp(const OurDaysApp());
}

const List<String> tabNames = ['Trang chủ', 'Bộ đếm', 'Sự kiện', 'Kỷ niệm', 'Ảnh', 'Thần số', 'Cài đặt'];
const List<IconData> tabIcons = [Icons.home_rounded, Icons.favorite_rounded, Icons.event_rounded, Icons.auto_awesome_rounded, Icons.photo_library_rounded, Icons.auto_graph_rounded, Icons.settings_rounded];
const Map<String, Color> palettes = {
  'rose': Color(0xFFFF83B5), 'lavender': Color(0xFFB9A5FF), 'ocean': Color(0xFF71BDF2),
  'mint': Color(0xFF71D9C0), 'sunset': Color(0xFFFFA36C),
};
const Map<int, String> numerologyMeaning = {
  1: 'Biểu tượng của sự chủ động, tinh thần bắt đầu và tự lập.',
  2: 'Biểu tượng của hợp tác, lắng nghe và sự tinh tế trong kết nối.',
  3: 'Biểu tượng của biểu đạt, sáng tạo và niềm vui.',
  4: 'Biểu tượng của nền tảng, tính kiên trì và sự ổn định.',
  5: 'Biểu tượng của trải nghiệm, thay đổi và khám phá.',
  6: 'Biểu tượng của sự quan tâm, trách nhiệm và chăm sóc.',
  7: 'Biểu tượng của suy ngẫm, học hỏi và chiều sâu nội tâm.',
  8: 'Biểu tượng của mục tiêu, tổ chức và ý chí thực hiện.',
  9: 'Biểu tượng của lòng trắc ẩn, sự sẻ chia và hoàn thiện.',
  11: 'Con số chủ đạo đặc biệt trong một số trường phái: trực giác và cảm hứng.',
  22: 'Con số chủ đạo đặc biệt trong một số trường phái: tầm nhìn và xây dựng.',
  33: 'Con số chủ đạo đặc biệt trong một số trường phái: lòng nhân ái và phụng sự.',
};
const Map<int, String> personalYearMeaning = {
  1: 'Khởi đầu và thử điều mới.', 2: 'Hợp tác và kiên nhẫn.', 3: 'Sáng tạo và bày tỏ.',
  4: 'Xây nền tảng và sắp xếp.', 5: 'Thay đổi và trải nghiệm.', 6: 'Gia đình và sự quan tâm.',
  7: 'Học hỏi và nhìn lại.', 8: 'Mục tiêu và thành quả.', 9: 'Tổng kết và buông điều không cần thiết.',
};

class OurDaysApp extends StatefulWidget {
  const OurDaysApp({super.key});
  @override
  State<OurDaysApp> createState() => _OurDaysAppState();
}

class _OurDaysAppState extends State<OurDaysApp> {
  final DataStore store = DataStore();
  final ImagePicker picker = ImagePicker();
  Timer? tick;
  bool ready = false;
  bool intro = true;
  int selectedTab = 0;
  int profileRevision = 0;

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    await store.init();
    if (!mounted) return;
    setState(() => ready = true);
    tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && selectedTab == 1) setState(() {});
      if (DateTime.now().second == 0) _checkImportantNotifications();
    });
    _checkImportantNotifications();
  }

  @override
  void dispose() { tick?.cancel(); store.dispose(); super.dispose(); }

  Color get accent => palettes[store.data['themePalette']] ?? palettes['rose']!;
  bool get dark => store.data['themeMode'] == 'dark';
  void showMessage(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text), behavior: SnackBarBehavior.floating, duration: const Duration(seconds: 2)));
  }

  Future<String> pickImage({required String prefix}) async {
    try {
      final x = await picker.pickImage(source: ImageSource.gallery, maxWidth: 1400, maxHeight: 1400, imageQuality: 76);
      if (x == null) return '';
      return await store.saveImageBytes(await x.readAsBytes(), prefix);
    } catch (e) { showMessage('Không thể mở ảnh: $e'); return ''; }
  }

  Future<List<String>> pickManyImages() async {
    try {
      final selected = await picker.pickMultiImage(maxWidth: 1400, maxHeight: 1400, imageQuality: 76, limit: 20);
      final paths = <String>[];
      for (var i = 0; i < selected.length && i < 20; i++) {
        paths.add(await store.saveImageBytes(await selected[i].readAsBytes(), 'album_$i'));
      }
      return paths;
    } catch (e) { showMessage('Không thể đọc ảnh đã chọn: $e'); return []; }
  }

  Future<void> _checkImportantNotifications() async {
    if (!ready || store.data['notificationsEnabled'] != true) return;
    final start = parseDate(store.data['startDate']) ?? DateTime.now();
    final days = currentDays(start);
    const milestones = [7, 14, 30, 50, 100, 200, 300, 365, 500, 730, 1000, 1500, 2000, 3000, 3650];
    if (milestones.contains(days) && store.data['lastNotifiedMilestone'] != days) {
      await _notify(101, 'Cột mốc mới 💗', 'Hôm nay là ngày thứ $days bên nhau. Chúc mừng hai bạn!');
      store.data['lastNotifiedMilestone'] = days;
      await store.save();
    }
    final today = isoDate(DateTime.now());
    final last = Map<String, dynamic>.from(store.data['lastNotifiedBirthday'] as Map);
    var changed = false;
    for (final p in [
      ('one', parseDate(store.data['birthDateOne']), (store.data['personOne'] ?? 'Mình').toString()),
      ('two', parseDate(store.data['birthDateTwo']), (store.data['personTwo'] ?? 'Người ấy').toString()),
    ]) {
      final info = birthdayInfo(p.$2);
      if (info != null && info.remaining == 0 && last[p.$1] != today) {
        await _notify(p.$1 == 'one' ? 102 : 103, '🎂 Sinh nhật hôm nay!', 'Hôm nay là sinh nhật ${p.$3}! Chúc một tuổi mới thật nhiều niềm vui.');
        last[p.$1] = today;
        changed = true;
      }
    }
    if (changed) {
      store.data['lastNotifiedBirthday'] = last;
      await store.save();
    }
  }

  Future<void> _notify(int id, String title, String body) async {
    const details = NotificationDetails(
      android: AndroidNotificationDetails('our_days_reminders', 'Our Days · Nhắc nhở', channelDescription: 'Nhắc cột mốc ngày yêu và sinh nhật', importance: Importance.high, priority: Priority.high),
      iOS: DarwinNotificationDetails(),
    );
    try { await notifications.show(id: id, title: title, body: body, notificationDetails: details); } catch (_) { /* Permission may not have been granted yet. */ }
  }

  Future<void> requestNotifications() async {
    try {
      final android = notifications.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      final ios = notifications.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>();
      final a = await android?.requestNotificationsPermission();
      final i = await ios?.requestPermissions(alert: true, badge: true, sound: true);
      final granted = a ?? i ?? true;
      store.data['notificationsEnabled'] = granted;
      await store.save();
      showMessage(granted ? 'Đã bật nhắc nhở trên thiết bị.' : 'Bạn chưa cấp quyền thông báo.');
    } catch (e) { showMessage('Không thể bật thông báo: $e'); }
  }

  Future<void> exportBackup() async {
    try {
      final payload = await store.createBackup();
      final temp = await getTemporaryDirectory();
      final file = File('${temp.path}/our-days-backup-${isoDate(DateTime.now())}.json');
      await file.writeAsString(jsonEncode(payload), flush: true);
      await SharePlus.instance.share(ShareParams(title: 'Sao lưu Our Days', text: 'Bản sao lưu dữ liệu Our Days V4.8', files: [XFile(file.path)]));
    } catch (e) { showMessage('Không thể tạo bản sao lưu: $e'); }
  }

  Future<void> importBackup({required bool merge, bool albumOnly = false}) async {
    try {
      final file = await FilePicker.pickFile(type: FileType.custom, allowedExtensions: ['json']);
      if (file == null) return;
      final fileSize = await file.length();
      if (fileSize != null && fileSize > 120 * 1024 * 1024) {
        throw const FormatException('Tệp lớn hơn 120 MB. Hãy chia nhỏ album rồi nhập từng phần.');
      }
      final raw = utf8.decode(await file.readAsBytes());
      final parsed = jsonDecode(raw);
      if (parsed is! Map) throw const FormatException('Tệp JSON không hợp lệ.');
      final map = Map<String, dynamic>.from(parsed);
      if (albumOnly) {
        final list = map['type'] == 'our-days-album' ? map['photos'] : map['photos'];
        if (list is! List) throw const FormatException('Tệp không chứa album ảnh Our Days.');
        final backup = <String, dynamic>{'app': 'Our Days', 'data': {'startDate': store.data['startDate'], 'personOne': store.data['personOne'], 'personTwo': store.data['personTwo'], 'photos': list, 'memories': []}};
        await store.importBackup(backup, merge: true);
      } else {
        await store.importBackup(map, merge: merge);
        if (!merge && selectedTab == 6 && mounted) setState(() => profileRevision++);
      }
      showMessage(albumOnly ? 'Đã nhập album ảnh.' : (merge ? 'Đã gộp dữ liệu từ tệp.' : 'Đã khôi phục dữ liệu từ tệp.'));
    } catch (e) { showMessage('Không thể nhập tệp: $e'); }
  }

  Future<void> exportAlbum() async {
    try {
      final backup = await store.createBackup();
      final payload = {'app': 'Our Days', 'type': 'our-days-album', 'schemaVersion': 1, 'exportedAt': DateTime.now().toIso8601String(), 'photos': (backup['data'] as Map)['photos']};
      final temp = await getTemporaryDirectory();
      final file = File('${temp.path}/our-days-album-${isoDate(DateTime.now())}.json');
      await file.writeAsString(jsonEncode(payload), flush: true);
      await SharePlus.instance.share(ShareParams(title: 'Album Our Days', files: [XFile(file.path)]));
    } catch (e) { showMessage('Không thể xuất album: $e'); }
  }

  Future<void> sharePhoto(String path, String caption) async {
    final f = store.assetFile(path);
    if (f == null || !await f.exists()) { showMessage('Không tìm thấy tệp ảnh.'); return; }
    try { await SharePlus.instance.share(ShareParams(title: caption, text: caption, files: [XFile(f.path)])); }
    catch (e) { showMessage('Không thể chia sẻ ảnh: $e'); }
  }

  @override
  Widget build(BuildContext context) {
    if (!ready) return MaterialApp(debugShowCheckedModeBanner: false, home: Scaffold(body: Center(child: CircularProgressIndicator(color: palettes['rose']))));
    final bg = dark ? const Color(0xFF181326) : const Color(0xFFFFF8FC);
    final fg = dark ? const Color(0xFFFFF7FF) : const Color(0xFF49364F);
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) => MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(useMaterial3: true, brightness: dark ? Brightness.dark : Brightness.light, scaffoldBackgroundColor: bg, colorScheme: ColorScheme.fromSeed(seedColor: accent, brightness: dark ? Brightness.dark : Brightness.light), appBarTheme: AppBarTheme(backgroundColor: bg, foregroundColor: fg, elevation: 0)),
        home: Stack(children: [
          Scaffold(
            extendBody: true,
            appBar: AppBar(
              title: const Text('Our Days', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: -.5)),
              actions: [
                IconButton(tooltip: 'Chia sẻ ngày yêu', onPressed: _shareSummary, icon: const Icon(Icons.ios_share_rounded)),
                IconButton(tooltip: 'Tùy chỉnh', onPressed: () => setState(() => selectedTab = 6), icon: const Icon(Icons.tune_rounded)),
                const SizedBox(width: 5),
              ],
            ),
            body: Stack(
              fit: StackFit.expand,
              children: [
                if (store.data['background']?.toString().isNotEmpty == true)
                  Positioned.fill(
                    child: Opacity(
                      opacity: .13,
                      child: _AssetImage(
                        store: store,
                        path: store.data['background'].toString(),
                        fallback: '',
                      ),
                    ),
                  ),
                AnimatedSwitcher(
                  duration: Duration(milliseconds: store.data['performanceLevel'] == 'low' ? 0 : 330),
                  transitionBuilder: (child, animation) => FadeTransition(opacity: animation, child: child),
                  child: _pageForTab(key: ValueKey(selectedTab)),
                ),
              ],
            ),
            bottomNavigationBar: _bottomDock(),
          ),
          if (intro) _introScreen(),
        ]),
      ),
    );
  }

  Widget _pageForTab({required Key key}) {
    switch (selectedTab) {
      case 0: return HomePage(key: key, store: store, accent: accent, goTo: (n) => setState(() => selectedTab = n));
      case 1: return CounterPage(key: key, store: store, accent: accent);
      case 2: return EventsPage(key: key, store: store, accent: accent);
      case 3: return MemoriesPage(key: key, store: store, accent: accent, pickImage: () => pickImage(prefix: 'memory'));
      case 4: return PhotosPage(key: key, store: store, accent: accent, pickManyImages: pickManyImages, sharePhoto: sharePhoto, exportAlbum: exportAlbum, importAlbum: () => importBackup(merge: true, albumOnly: true));
      case 5: return NumerologyPage(key: key, store: store, accent: accent);
      default: return SettingsPage(key: ValueKey('settings-$profileRevision'), store: store, accent: accent, pickImage: pickImage, onNotify: requestNotifications, onTestNotify: () => _notify(199, 'Our Days 💗', 'Một ngày nữa được ở bên nhau. Hãy lưu lại khoảnh khắc nhé!'), onExport: exportBackup, onImport: (merge) => importBackup(merge: merge), onClear: _clearAll);
    }
  }

  Widget _bottomDock() {
    return SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(8, 0, 8, 8), child: ClipRRect(borderRadius: BorderRadius.circular(24), child: Container(
      decoration: BoxDecoration(color: dark ? const Color(0xE8272038) : const Color(0xEFFFFFFF), border: Border.all(color: accent.withOpacity(.22)), borderRadius: BorderRadius.circular(24), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.10), blurRadius: 24, offset: const Offset(0, 8))]),
      child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: List.generate(tabNames.length, (i) {
        final active = selectedTab == i;
        return InkWell(onTap: () => setState(() => selectedTab = i), borderRadius: BorderRadius.circular(18), child: AnimatedContainer(duration: const Duration(milliseconds: 190), margin: const EdgeInsets.symmetric(horizontal: 3, vertical: 5), padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9), decoration: BoxDecoration(color: active ? accent.withOpacity(.20) : Colors.transparent, borderRadius: BorderRadius.circular(18)), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(tabIcons[i], size: 19, color: active ? accent : (dark ? Colors.white70 : Colors.black54)), const SizedBox(height: 2), Text(tabNames[i], style: TextStyle(fontSize: 10, fontWeight: active ? FontWeight.w800 : FontWeight.w600, color: active ? accent : (dark ? Colors.white70 : Colors.black54))) ])));
      }))),
    ))));
  }

  Widget _introScreen() {
    final names = '${store.data['personOne']}  ♡  ${store.data['personTwo']}';
    final days = currentDays(parseDate(store.data['startDate']) ?? DateTime.now());
    return Positioned.fill(child: Material(color: Colors.transparent, child: Container(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [const Color(0xFF19132A), accent.withOpacity(.78), const Color(0xFF3E294B)])), child: SafeArea(child: Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(Icons.favorite_rounded, color: accent, size: 76),
      const SizedBox(height: 18), const Text('OUR DAYS', style: TextStyle(color: Colors.white, fontSize: 33, fontWeight: FontWeight.w900, letterSpacing: 4)),
      const SizedBox(height: 10), Text(names, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700)),
      const SizedBox(height: 10), Text('Đã bên nhau ${formatNumber(days)} ngày · và còn nhiều ngày phía trước', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70, fontSize: 13)),
      const SizedBox(height: 40), FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: accent, foregroundColor: const Color(0xFF47243B), padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 15)), onPressed: () => setState(() => intro = false), icon: const Icon(Icons.favorite_border_rounded), label: const Text('Mở không gian của chúng mình', style: TextStyle(fontWeight: FontWeight.w800))),
      const SizedBox(height: 14), const Text('OUR DAYS · NATIVE EDITION', style: TextStyle(color: Colors.white38, fontSize: 9, letterSpacing: 2)),
    ])))))));
  }

  Future<void> _shareSummary() async {
    final start = parseDate(store.data['startDate']) ?? DateTime.now();
    final text = '${store.data['personOne']} & ${store.data['personTwo']}\nĐã bên nhau ${formatNumber(currentDays(start))} ngày 💗\nTừ ${formatDate(start)}';
    try { await SharePlus.instance.share(ShareParams(title: 'Our Days', text: text)); }
    catch (_) { showMessage(text); }
  }

  Future<void> _clearAll() async {
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('Xóa dữ liệu?'), content: const Text('Thao tác này sẽ xóa hồ sơ, ngày yêu, ảnh và kỷ niệm trên thiết bị. Hãy xuất bản sao lưu trước nếu cần.'), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Hủy')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Xóa tất cả'))]));
    if (ok == true) { await store.clearAll(); if (mounted) setState(() => profileRevision++); showMessage('Đã xóa dữ liệu trên thiết bị.'); }
  }
}

class GlassCard extends StatelessWidget {
  const GlassCard({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.margin = const EdgeInsets.only(bottom: 14), this.radius = 24, this.color});
  final Widget child; final EdgeInsets padding, margin; final double radius; final Color? color;
  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(margin: margin, decoration: BoxDecoration(borderRadius: BorderRadius.circular(radius), border: Border.all(color: (color ?? Theme.of(context).colorScheme.primary).withOpacity(isDark ? .24 : .18)), boxShadow: [BoxShadow(color: Colors.black.withOpacity(isDark ? .13 : .035), blurRadius: 20, offset: const Offset(0, 8))]), child: ClipRRect(borderRadius: BorderRadius.circular(radius), child: BackdropFilter(filter: ImageFilter.blur(sigmaX: 9, sigmaY: 9), child: Container(color: isDark ? const Color(0xAA302640) : const Color(0xDFFFFFFF), padding: padding, child: child))));
  }
}

class PageShell extends StatelessWidget {
  const PageShell({super.key, required this.title, required this.subtitle, required this.accent, required this.children});
  final String title, subtitle; final Color accent; final List<Widget> children;
  @override
  Widget build(BuildContext context) => SingleChildScrollView(key: key, physics: const BouncingScrollPhysics(), padding: const EdgeInsets.fromLTRB(16, 5, 16, 110), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(subtitle, style: TextStyle(color: Theme.of(context).textTheme.bodySmall?.color?.withOpacity(.72), fontSize: 12)), const SizedBox(height: 18), ...children]));
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.title, {super.key, this.trailing});
  final String title; final Widget? trailing;
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 12), child: Row(children: [Expanded(child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900))), if (trailing != null) trailing!]));
}

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.store, required this.accent, required this.goTo});
  final DataStore store; final Color accent; final ValueChanged<int> goTo;
  @override
  Widget build(BuildContext context) {
    final d = store.data; final start = parseDate(d['startDate']) ?? DateTime.now(); final days = currentDays(start);
    final upcoming = <Map<String, dynamic>>[];
    for (final p in [('one', d['personOne'], parseDate(d['birthDateOne'])), ('two', d['personTwo'], parseDate(d['birthDateTwo']))]) {
      final info = birthdayInfo(p.$3);
      if (info != null) upcoming.add({'title': 'Sinh nhật ${p.$2}', 'date': info.nextDate, 'remaining': info.remaining, 'icon': '🎂'});
    }
    upcoming.addAll([
      {'title': 'Valentine', 'date': nextRecurringDate(2, 14), 'remaining': nextRecurringDate(2, 14).difference(dateOnly(DateTime.now())).inDays, 'icon': '💌'},
      {'title': 'Quốc tế Phụ nữ 8/3', 'date': nextRecurringDate(3, 8), 'remaining': nextRecurringDate(3, 8).difference(dateOnly(DateTime.now())).inDays, 'icon': '🌷'},
      {'title': 'Phụ nữ Việt Nam 20/10', 'date': nextRecurringDate(10, 20), 'remaining': nextRecurringDate(10, 20).difference(dateOnly(DateTime.now())).inDays, 'icon': '🎀'},
    ]);
    final completedYears = (DateTime.now().year - start.year).clamp(0, 10000).toInt();
    var anniv = addCalendarYears(start, completedYears);
    if (anniv.isBefore(dateOnly(DateTime.now()))) anniv = addCalendarYears(start, completedYears + 1);
    upcoming.add({'title': 'Kỷ niệm ngày yêu', 'date': anniv, 'remaining': anniv.difference(dateOnly(DateTime.now())).inDays.clamp(0, 200000).toInt(), 'icon': '💗'});
    upcoming.sort((a, b) => (a['remaining'] as int).compareTo(b['remaining'] as int));
    final memoryList = (d['memories'] as List).cast<Map<String, dynamic>>().toList()..sort((a,b) => (b['date'] as String).compareTo(a['date'] as String));
    return PageShell(title: 'Một góc nhỏ của chúng mình', subtitle: 'Những ngày bình thường cũng có thể trở nên đáng nhớ.', accent: accent, children: [
      GlassCard(color: accent, padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [const Expanded(child: Text('OUR LITTLE STORY', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 2))), Icon(Icons.favorite_rounded, color: accent, size: 20)]), const SizedBox(height: 12), Text('${d['personOne']}  ♡  ${d['personTwo']}', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)), const SizedBox(height: 5), Text('Đã bên nhau', style: TextStyle(color: Theme.of(context).textTheme.bodySmall?.color)), Row(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(formatNumber(days), style: TextStyle(fontSize: 52, height: 1, fontWeight: FontWeight.w900, color: accent)), const Padding(padding: EdgeInsets.only(bottom: 7, left: 7), child: Text('ngày', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800)))]), Text('Từ ${formatDate(start)}', style: TextStyle(fontSize: 11, color: Theme.of(context).textTheme.bodySmall?.color)), const SizedBox(height: 14), ClipRRect(borderRadius: BorderRadius.circular(20), child: LinearProgressIndicator(value: annualProgressInfo(start, DateTime.now()).percent / 100, minHeight: 8, backgroundColor: accent.withOpacity(.16), color: accent)), const SizedBox(height: 7), Text('${annualProgressInfo(start, DateTime.now()).percent}% tiến trình năm thứ ${annualProgressInfo(start, DateTime.now()).years + 1}', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700))])),
      const SectionTitle('Mở nhanh'),
      GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, childAspectRatio: 2.3, mainAxisSpacing: 9, crossAxisSpacing: 9, children: [
        _Shortcut('Bộ đếm ngày', Icons.favorite_rounded, accent, () => goTo(1)), _Shortcut('Sự kiện', Icons.event_rounded, accent, () => goTo(2)),
        _Shortcut('Kỷ niệm', Icons.auto_awesome_rounded, accent, () => goTo(3)), _Shortcut('Thần số học', Icons.auto_graph_rounded, accent, () => goTo(5)),
      ]),
      const SizedBox(height: 16),
      GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const SectionTitle('Sắp tới'), if (upcoming.isEmpty) const Text('Thêm ngày sinh để theo dõi sinh nhật.') else ...upcoming.take(3).map((e) => ListTile(contentPadding: EdgeInsets.zero, leading: CircleAvatar(backgroundColor: accent.withOpacity(.15), child: Text(e['icon'] as String)), title: Text(e['title'] as String, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)), subtitle: Text(formatDate(e['date'] as DateTime)), trailing: Text((e['remaining'] as int) == 0 ? 'Hôm nay' : 'Còn ${e['remaining']} ngày', style: TextStyle(color: accent, fontWeight: FontWeight.w800, fontSize: 11))))])),
      GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [SectionTitle('Kỷ niệm gần đây', trailing: TextButton(onPressed: () => goTo(3), child: const Text('Tất cả'))), if (memoryList.isEmpty) const Text('Album vẫn đang chờ những khoảnh khắc đầu tiên 💞', style: TextStyle(fontSize: 12)) else ...memoryList.take(2).map((m) => ListTile(contentPadding: EdgeInsets.zero, leading: _AssetThumb(store: store, path: m['photo']?.toString(), fallback: '💌'), title: Text(m['title'].toString(), style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text(formatDate(parseDate(m['date']) ?? DateTime.now()))))]))
    ]);
  }
}

class _Shortcut extends StatelessWidget {
  const _Shortcut(this.label, this.icon, this.accent, this.onTap);
  final String label; final IconData icon; final Color accent; final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(18), child: GlassCard(margin: EdgeInsets.zero, padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9), child: Row(children: [Icon(icon, color: accent, size: 21), const SizedBox(width: 9), Expanded(child: Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800)))])));
}

class CounterPage extends StatefulWidget {
  const CounterPage({super.key, required this.store, required this.accent});
  final DataStore store; final Color accent;
  @override
  State<CounterPage> createState() => _CounterPageState();
}

class _CounterPageState extends State<CounterPage> {
  bool elapsed = false;
  String progressShape = 'heart';
  @override
  Widget build(BuildContext context) {
    final d = widget.store.data;
    final start = parseDate(d['startDate']) ?? DateTime.now();
    final now = DateTime.now();
    final days = currentDays(start, now);
    final milestone = nextMilestone(days);
    final annual = annualProgressInfo(start, now);
    final parts = elapsedCalendarParts(start, now);

    return GestureDetector(
      onHorizontalDragEnd: (details) {
        if ((details.primaryVelocity ?? 0) < -200) {
          setState(() => elapsed = true);
        }
        if ((details.primaryVelocity ?? 0) > 200) {
          setState(() => elapsed = false);
        }
      },
      child: PageShell(
        title: 'Bộ đếm ngày yêu',
        subtitle: elapsed
            ? 'Vuốt sang trái để quay lại bộ đếm ngày'
            : 'Vuốt sang phải để xem tổng thời gian năm · tháng · ngày · giờ · phút · giây',
        accent: widget.accent,
        children: [
          if (!elapsed) ...[
            GlassCard(
              color: widget.accent,
              padding: const EdgeInsets.fromLTRB(15, 16, 15, 18),
              child: Column(
                children: [
                  Text(
                    '${d['personOne']}  ♡  ${d['personTwo']}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 5),
                  const Text(
                    'ĐÃ Ở BÊN NHAU',
                    style: TextStyle(fontSize: 9, letterSpacing: 2, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: 246,
                    height: 230,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        CustomPaint(
                          size: const Size(222, 222),
                          painter: ProgressShapePainter(
                            progress: annual.percent / 100,
                            color: widget.accent,
                            shape: progressShape,
                            dark: Theme.of(context).brightness == Brightness.dark,
                          ),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              formatNumber(days),
                              style: TextStyle(
                                fontSize: 49,
                                height: 1,
                                letterSpacing: -2.4,
                                fontWeight: FontWeight.w900,
                                color: widget.accent,
                              ),
                            ),
                            const SizedBox(height: 4),
                            const Text('ngày', style: TextStyle(fontWeight: FontWeight.w800)),
                            Text(
                              '${annual.percent}% của năm thứ ${annual.years + 1}',
                              style: TextStyle(
                                fontSize: 9,
                                color: Theme.of(context).textTheme.bodySmall?.color,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ChoiceChip(
                        label: const Text('♥ Trái tim'),
                        selected: progressShape == 'heart',
                        onSelected: (_) => setState(() => progressShape = 'heart'),
                        selectedColor: widget.accent.withOpacity(.2),
                      ),
                      const SizedBox(width: 8),
                      ChoiceChip(
                        label: const Text('◯ Vòng tròn'),
                        selected: progressShape == 'circle',
                        onSelected: (_) => setState(() => progressShape = 'circle'),
                        selectedColor: widget.accent.withOpacity(.2),
                      ),
                    ],
                  ),
                  const SizedBox(height: 9),
                  Text(
                    'Còn ${formatNumber(annual.daysLeft)} ngày đến kỷ niệm ${annual.years + 1} năm',
                    style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    'Mốc tiếp theo: $milestone ngày · còn $remainDayText',
                    style: TextStyle(fontSize: 10, color: Theme.of(context).textTheme.bodySmall?.color),
                  ),
                ],
              ),
            ),
            GlassCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SectionTitle('Hồ sơ sinh nhật'),
                  Row(
                    children: [
                      Expanded(child: _ProfileMini(store: widget.store, one: true, accent: widget.accent)),
                      const SizedBox(width: 10),
                      Expanded(child: _ProfileMini(store: widget.store, one: false, accent: widget.accent)),
                    ],
                  ),
                ],
              ),
            ),
            GlassCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SectionTitle('Những con số của chúng mình'),
                  GridView.count(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 2,
                    childAspectRatio: 1.8,
                    children: [
                      MiniStat(value: '${days ~/ 30.436875}', label: 'tháng bên nhau', icon: '🌷', accent: widget.accent),
                      MiniStat(value: '${days ~/ 7}', label: 'tuần bên nhau', icon: '☁️', accent: widget.accent),
                      MiniStat(value: '${now.difference(start).inHours}', label: 'giờ đã trôi qua', icon: '⏳', accent: widget.accent),
                      MiniStat(value: '${now.difference(start).inMinutes}', label: 'phút đáng nhớ', icon: '💗', accent: widget.accent),
                    ],
                  ),
                ],
              ),
            ),
            GlassCard(
              child: Row(
                children: [
                  const Icon(Icons.flag_rounded),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('$milestone ngày bên nhau', style: const TextStyle(fontWeight: FontWeight.w900)),
                        Text('Dự kiến · ${formatDate(start.add(Duration(days: milestone - 1)))}', style: const TextStyle(fontSize: 11)),
                      ],
                    ),
                  ),
                  Text(
                    days >= milestone ? 'Hôm nay!' : 'Còn $remainDayText',
                    style: TextStyle(color: widget.accent, fontWeight: FontWeight.w900),
                  ),
                ],
              ),
            ),
          ] else ...[
            GlassCard(
              color: widget.accent,
              child: Column(
                children: [
                  const Text('OUR LITTLE TIMELINE', style: TextStyle(fontSize: 9, letterSpacing: 2, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 8),
                  const Text('Tổng thời gian bên nhau', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                  Text('Từ ${formatDate(start)} · ${d['personOne']} & ${d['personTwo']}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 10)),
                  const SizedBox(height: 18),
                  GridView.count(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 3,
                    mainAxisSpacing: 9,
                    crossAxisSpacing: 9,
                    childAspectRatio: 1.05,
                    children: [
                      ElapsedUnit(value: parts.years, label: 'Năm', accent: widget.accent),
                      ElapsedUnit(value: parts.months, label: 'Tháng', accent: widget.accent),
                      ElapsedUnit(value: parts.days, label: 'Ngày', accent: widget.accent),
                      ElapsedUnit(value: parts.hours, label: 'Giờ', accent: widget.accent),
                      ElapsedUnit(value: parts.minutes, label: 'Phút', accent: widget.accent),
                      ElapsedUnit(value: parts.seconds, label: 'Giây', accent: widget.accent),
                    ],
                  ),
                  const SizedBox(height: 10),
                  const Text('Đếm trực tiếp theo lịch, có tính năm nhuận và độ dài từng tháng.', style: TextStyle(fontSize: 10)),
                ],
              ),
            ),
          ],
          Center(
            child: TextButton.icon(
              onPressed: () => setState(() => elapsed = !elapsed),
              icon: Icon(elapsed ? Icons.chevron_left_rounded : Icons.chevron_right_rounded),
              label: Text(elapsed ? 'Quay lại bộ đếm' : 'Xem tổng thời gian'),
            ),
          ),
        ],
      ),
    );
  }

  String get remainDayText { final days = currentDays(parseDate(widget.store.data['startDate']) ?? DateTime.now()); final n = nextMilestone(days) - days; return '$n ngày'; }
}

class ProgressShapePainter extends CustomPainter {
  ProgressShapePainter({required this.progress, required this.color, required this.shape, required this.dark});
  final double progress; final Color color; final String shape; final bool dark;
  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final p = Paint()..style = PaintingStyle.stroke..strokeWidth = 5.2..strokeCap = StrokeCap.round..color = dark ? Colors.white24 : const Color(0x2B7F637B);
    Path path;
    if (shape == 'circle') {
      path = Path()..addOval(Rect.fromCircle(center: rect.center, radius: math.min(size.width, size.height) * .43));
    } else {
      path = Path()..moveTo(size.width * .5, size.height * .89)
        ..cubicTo(size.width * .39, size.height * .77, size.width * .06, size.height * .57, size.width * .06, size.height * .31)
        ..cubicTo(size.width * .06, size.height * .05, size.width * .34, size.height * .03, size.width * .5, size.height * .21)
        ..cubicTo(size.width * .66, size.height * .03, size.width * .94, size.height * .05, size.width * .94, size.height * .31)
        ..cubicTo(size.width * .94, size.height * .57, size.width * .61, size.height * .77, size.width * .5, size.height * .89);
    }
    canvas.drawPath(path, p);
    final metric = path.computeMetrics().first;
    final fill = Paint()..style = PaintingStyle.stroke..strokeWidth = 5.7..strokeCap = StrokeCap.round..shader = LinearGradient(colors: [color.withOpacity(.55), color, color.withOpacity(.75)]).createShader(rect);
    canvas.drawPath(metric.extractPath(0, metric.length * progress.clamp(0, 1).toDouble()), fill);
    final glow = Paint()..color = color.withOpacity(.04)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 17);
    canvas.drawCircle(rect.center, size.width * .33, glow);
  }
  @override
  bool shouldRepaint(covariant ProgressShapePainter old) => old.progress != progress || old.color != color || old.shape != shape || old.dark != dark;
}

class MiniStat extends StatelessWidget {
  const MiniStat({required this.value, required this.label, required this.icon, required this.accent});
  final String value, label, icon; final Color accent;
  @override
  Widget build(BuildContext context) => Container(margin: const EdgeInsets.all(5), padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: accent.withOpacity(.08), borderRadius: BorderRadius.circular(16)), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(icon, style: const TextStyle(fontSize: 17)), Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 20, color: accent, fontWeight: FontWeight.w900)), Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w700))]));
}

class ElapsedUnit extends StatelessWidget {
  const ElapsedUnit({required this.value, required this.label, required this.accent});
  final int value; final String label; final Color accent;
  @override
  Widget build(BuildContext context) => Container(decoration: BoxDecoration(color: accent.withOpacity(.11), borderRadius: BorderRadius.circular(18), border: Border.all(color: accent.withOpacity(.18))), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(formatNumber(value), style: TextStyle(color: accent, fontSize: 26, fontWeight: FontWeight.w900, letterSpacing: -1)), Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700))]));
}

class _ProfileMini extends StatelessWidget {
  const _ProfileMini({required this.store, required this.one, required this.accent});
  final DataStore store; final bool one; final Color accent;
  @override
  Widget build(BuildContext context) {
    final d = store.data; final birth = parseDate(d[one ? 'birthDateOne' : 'birthDateTwo']); final info = birthdayInfo(birth); final path = d[one ? 'avatarOne' : 'avatarTwo']?.toString() ?? '';
    return Column(children: [Stack(alignment: Alignment.center, children: [SizedBox(width: 80, height: 80, child: CircularProgressIndicator(value: info?.progress ?? 0, strokeWidth: 4, color: accent, backgroundColor: accent.withOpacity(.15))), Padding(padding: const EdgeInsets.all(7), child: ClipOval(child: SizedBox(width: 63, height: 63, child: _AssetImage(store: store, path: path, fallback: one ? '🧸' : '🐰')))), Positioned(bottom: 0, child: Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3), decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(12)), child: Text(info == null ? '🎂' : (info.remaining == 0 ? 'HÔM NAY' : '${info.remaining}d'), style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w900))))]), const SizedBox(height: 7), Text((d[one ? 'personOne' : 'personTwo'] ?? '').toString(), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12)), Text('${d[one ? 'genderOne' : 'genderTwo']?.toString().isNotEmpty == true ? d[one ? 'genderOne' : 'genderTwo'] : 'Chưa cập nhật'} · ${info == null ? 'Chưa rõ tuổi' : '${info.age} tuổi'}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 9)), Text(info == null ? 'Thêm ngày sinh' : (info.remaining == 0 ? 'Sinh nhật hôm nay!' : 'Còn ${info.remaining} ngày'), style: TextStyle(fontSize: 9, color: accent, fontWeight: FontWeight.w800))]);
  }
}

class _AssetThumb extends StatelessWidget {
  const _AssetThumb({required this.store, required this.path, required this.fallback});
  final DataStore store; final String? path; final String fallback;
  @override
  Widget build(BuildContext context) => ClipRRect(borderRadius: BorderRadius.circular(12), child: SizedBox(width: 48, height: 48, child: _AssetImage(store: store, path: path ?? '', fallback: fallback)));
}

class _AssetImage extends StatelessWidget {
  const _AssetImage({required this.store, required this.path, required this.fallback});
  final DataStore store; final String path, fallback;
  @override
  Widget build(BuildContext context) {
    final file = store.assetFile(path);
    if (file != null && file.existsSync()) return Image.file(file, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _fallback());
    return _fallback();
  }
  Widget _fallback() => Container(color: Colors.white.withOpacity(.10), alignment: Alignment.center, child: Text(fallback, style: const TextStyle(fontSize: 23)));
}

class EventsPage extends StatelessWidget {
  const EventsPage({super.key, required this.store, required this.accent});
  final DataStore store; final Color accent;
  @override
  Widget build(BuildContext context) {
    final d = store.data;
    final today = dateOnly(DateTime.now());
    final events = <Map<String, dynamic>>[
      {'title': 'Valentine', 'date': nextRecurringDate(2, 14, today), 'subtitle': 'Ngày lễ tình yêu', 'icon': '💌'},
      {'title': 'Quốc tế Phụ nữ 8/3', 'date': nextRecurringDate(3, 8, today), 'subtitle': 'Gửi lời yêu thương đến những người phụ nữ', 'icon': '🌷'},
      {'title': 'Phụ nữ Việt Nam 20/10', 'date': nextRecurringDate(10, 20, today), 'subtitle': 'Ngày tôn vinh phụ nữ Việt Nam', 'icon': '🎀'},
    ];
    final people = [
      ('one', d['personOne'], parseDate(d['birthDateOne'])),
      ('two', d['personTwo'], parseDate(d['birthDateTwo'])),
    ];

    for (final person in people) {
      final info = birthdayInfo(person.$3);
      if (info != null) {
        events.add({
          'title': 'Sinh nhật ${person.$2}',
          'date': info.nextDate,
          'remaining': info.remaining,
          'subtitle': 'Tròn ${info.age + (info.remaining == 0 ? 0 : 1)} tuổi vào ngày này',
          'icon': '🎂',
        });
      }
    }

    final startDate = parseDate(d['startDate']) ?? DateTime.now();
    final completedYears = (DateTime.now().year - startDate.year).clamp(0, 10000).toInt();
    var anniversary = addCalendarYears(startDate, completedYears);
    if (anniversary.isBefore(dateOnly(DateTime.now()))) {
      anniversary = addCalendarYears(startDate, completedYears + 1);
    }
    events.add({
      'title': 'Kỷ niệm ngày yêu',
      'date': anniversary,
      'remaining': anniversary.difference(dateOnly(DateTime.now())).inDays.clamp(0, 100000).toInt(),
      'subtitle': 'Bắt đầu từ ${formatDate(startDate)}',
      'icon': '💗',
    });

    for (final event in events) {
      event['remaining'] = (event['date'] as DateTime).difference(today).inDays.clamp(0, 200000).toInt();
    }
    events.sort((a, b) => (a['remaining'] as num).compareTo(b['remaining'] as num));

    return PageShell(
      title: 'Sự kiện đặc biệt',
      subtitle: 'Sinh nhật và những ngày ý nghĩa của hai bạn.',
      accent: accent,
      children: [
        GlassCard(
          child: Column(
            children: [
              const SectionTitle('Những ngày đặc biệt'),
              ...events.map((event) {
                final remaining = event['remaining'] as num;
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: CircleAvatar(
                    backgroundColor: accent.withOpacity(.13),
                    child: Text(event['icon'] as String),
                  ),
                  title: Text(event['title'].toString(), style: const TextStyle(fontWeight: FontWeight.w900)),
                  subtitle: Text('${formatDate(event['date'] as DateTime)} · ${event['subtitle']}'),
                  trailing: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(remaining == 0 ? 'Hôm nay' : 'Còn', style: const TextStyle(fontSize: 9)),
                      Text(
                        remaining == 0 ? '✦' : '${remaining}d',
                        style: TextStyle(color: accent, fontWeight: FontWeight.w900),
                      ),
                    ],
                  ),
                );
              }),
            ],
          ),
        ),
      ],
    );
  }
}

class MemoriesPage extends StatefulWidget {
  const MemoriesPage({super.key, required this.store, required this.accent, required this.pickImage});
  final DataStore store; final Color accent; final Future<String> Function() pickImage;
  @override
  State<MemoriesPage> createState() => _MemoriesPageState();
}
class _MemoriesPageState extends State<MemoriesPage> {
  Future<void> _addMemory() async {
    final title = TextEditingController(); final note = TextEditingController(); DateTime date = DateTime.now(); String photo = '';
    final result = await showDialog<bool>(context: context, builder: (c) => StatefulBuilder(builder: (c, setD) => AlertDialog(title: const Text('Thêm một kỷ niệm'), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: title, maxLength: 60, decoration: const InputDecoration(labelText: 'Tên kỷ niệm', hintText: 'Buổi hẹn đầu tiên')), ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.calendar_month_rounded), title: Text(formatDate(date)), onTap: () async { final v = await showDatePicker(context: c, initialDate: date, firstDate: DateTime(1900), lastDate: DateTime(2100)); if (v != null) setD(() => date = v); }), TextField(controller: note, maxLength: 260, maxLines: 3, decoration: const InputDecoration(labelText: 'Một chút ghi chú')), OutlinedButton.icon(onPressed: () async { final p = await widget.pickImage(); if (p.isNotEmpty) setD(() => photo = p); }, icon: const Icon(Icons.add_photo_alternate_outlined), label: Text(photo.isEmpty ? 'Thêm ảnh (không bắt buộc)' : 'Đã chọn ảnh'))])), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Hủy')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Lưu'))])));
    if (result == true && title.text.trim().isNotEmpty) {
      final list = (widget.store.data['memories'] as List).cast<Map<String, dynamic>>();
      list.add({'id': 'memory-${DateTime.now().microsecondsSinceEpoch}', 'title': title.text.trim(), 'date': isoDate(date), 'note': note.text.trim(), 'photo': photo});
      await widget.store.save();
    }
    title.dispose(); note.dispose();
  }
  Future<void> _delete(Map<String, dynamic> m) async {
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('Xóa kỷ niệm?'), content: Text('Xóa “${m['title']}” khỏi album?'), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Hủy')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Xóa'))]));
    if (ok == true) { (widget.store.data['memories'] as List).removeWhere((e) => e['id'] == m['id']); await widget.store.save(); }
  }
  @override
  Widget build(BuildContext context) {
    final list = (widget.store.data['memories'] as List).cast<Map<String, dynamic>>().toList()..sort((a,b) => (b['date'] as String).compareTo(a['date'] as String));
    return PageShell(title: 'Album kỷ niệm', subtitle: 'Những khoảnh khắc nhỏ tạo nên câu chuyện của hai bạn.', accent: widget.accent, children: [FilledButton.icon(onPressed: _addMemory, icon: const Icon(Icons.add_rounded), label: const Text('Thêm một kỷ niệm')), const SizedBox(height: 14), if (list.isEmpty) GlassCard(child: const Center(child: Padding(padding: EdgeInsets.all(18), child: Text('Album của hai bạn vẫn đang chờ những khoảnh khắc đầu tiên 💞', textAlign: TextAlign.center)))) else ...list.map((m) => GlassCard(padding: const EdgeInsets.all(12), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [SizedBox(width: 84, height: 90, child: ClipRRect(borderRadius: BorderRadius.circular(16), child: _AssetImage(store: widget.store, path: m['photo']?.toString() ?? '', fallback: '💌'))), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(m['title'].toString(), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)), const SizedBox(height: 3), Text(formatDate(parseDate(m['date']) ?? DateTime.now()), style: TextStyle(color: widget.accent, fontWeight: FontWeight.w700, fontSize: 10)), if ((m['note'] ?? '').toString().isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(m['note'].toString(), style: const TextStyle(fontSize: 11))), Align(alignment: Alignment.centerRight, child: TextButton.icon(onPressed: () => _delete(m), icon: const Icon(Icons.delete_outline_rounded, size: 16), label: const Text('Xóa'))) ]))])) )]);
  }
}

class PhotosPage extends StatefulWidget {
  const PhotosPage({super.key, required this.store, required this.accent, required this.pickManyImages, required this.sharePhoto, required this.exportAlbum, required this.importAlbum});
  final DataStore store; final Color accent; final Future<List<String>> Function() pickManyImages; final Future<void> Function(String, String) sharePhoto; final VoidCallback exportAlbum; final VoidCallback importAlbum;
  @override
  State<PhotosPage> createState() => _PhotosPageState();
}
class _PhotosPageState extends State<PhotosPage> {
  final caption = TextEditingController();
  @override
  void dispose() { caption.dispose(); super.dispose(); }
  Future<void> _add() async {
    final paths = await widget.pickManyImages(); if (paths.isEmpty) return;
    final list = (widget.store.data['photos'] as List).cast<Map<String, dynamic>>();
    for (var i = 0; i < paths.length; i++) { list.add({'id': 'photo-${DateTime.now().microsecondsSinceEpoch}-$i', 'caption': caption.text.trim().isEmpty ? 'Một khoảnh khắc' : caption.text.trim(), 'date': isoDate(DateTime.now()), 'src': paths[i]}); }
    caption.clear(); await widget.store.save();
  }
  Future<void> _delete(Map<String, dynamic> p) async {
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('Xóa ảnh?'), content: Text('Xóa “${p['caption']}” khỏi album trên thiết bị?'), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Hủy')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Xóa'))]));
    if (ok == true) { (widget.store.data['photos'] as List).removeWhere((e) => e['id'] == p['id']); await widget.store.save(); }
  }
  @override
  Widget build(BuildContext context) {
    final list = (widget.store.data['photos'] as List).cast<Map<String, dynamic>>().reversed.toList();
    return PageShell(title: 'Ảnh của chúng mình', subtitle: 'Chọn ảnh từ máy, lưu album và chia sẻ bằng ứng dụng khác.', accent: widget.accent, children: [GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const SectionTitle('Thêm ảnh mới'), TextField(controller: caption, maxLength: 70, decoration: const InputDecoration(labelText: 'Ghi chú cho ảnh', hintText: 'Chiều hôm ấy 💗')), const SizedBox(height: 10), FilledButton.icon(onPressed: _add, icon: const Icon(Icons.add_photo_alternate_rounded), label: const Text('Chọn và lưu ảnh')), const SizedBox(height: 8), Wrap(spacing: 8, children: [OutlinedButton.icon(onPressed: widget.exportAlbum, icon: const Icon(Icons.file_upload_outlined), label: const Text('Xuất album JSON')), OutlinedButton.icon(onPressed: widget.importAlbum, icon: const Icon(Icons.file_download_outlined), label: const Text('Nhập album JSON'))]), const SizedBox(height: 6), const Text('Ảnh được lưu riêng trong bộ nhớ ứng dụng. Dùng sao lưu để chuyển album sang thiết bị khác.', style: TextStyle(fontSize: 10))])), GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [SectionTitle('Album ảnh', trailing: Text('${list.length} ảnh', style: TextStyle(color: widget.accent, fontWeight: FontWeight.w800))), if (list.isEmpty) const Center(child: Padding(padding: EdgeInsets.all(18), child: Text('Chưa có ảnh nào. Hãy thêm khoảnh khắc đầu tiên 📷'))) else GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: list.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 12, childAspectRatio: .77), itemBuilder: (context, i) { final p = list[i]; return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(17), child: SizedBox(width: double.infinity, child: _AssetImage(store: widget.store, path: p['src']?.toString() ?? '', fallback: '📷'))),), const SizedBox(height: 5), Text(p['caption'].toString(), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 11)), Text(formatDate(parseDate(p['date']) ?? DateTime.now()), style: const TextStyle(fontSize: 9)), Row(children: [IconButton(visualDensity: VisualDensity.compact, tooltip: 'Chia sẻ', onPressed: () => widget.sharePhoto(p['src'].toString(), p['caption'].toString()), icon: Icon(Icons.share_rounded, size: 18, color: widget.accent)), IconButton(visualDensity: VisualDensity.compact, tooltip: 'Xóa', onPressed: () => _delete(p), icon: const Icon(Icons.delete_outline_rounded, size: 18))])]); })]))]);
  }
}

class NumerologyPage extends StatelessWidget {
  const NumerologyPage({super.key, required this.store, required this.accent});
  final DataStore store; final Color accent;
  int? _reduce(int? n, {bool masters = true}) {
    if (n == null) return null; var value = n.abs();
    while (value > 9 && !(masters && [11, 22, 33].contains(value))) { value = value.toString().split('').fold<int>(0, (a, b) => a + int.parse(b)); }
    return value;
  }
  int? _life(DateTime? date) => date == null ? null : _reduce(isoDate(date).replaceAll('-', '').split('').fold<int>(0, (a,b) => a + int.parse(b)));
  int? _year(DateTime? date) => date == null ? null : _reduce('${date.day}${date.month}${DateTime.now().year}'.split('').fold<int>(0, (a,b) => a + int.parse(b)), masters: false);
  Widget _person(String name, int? path, int? year, Color accent) => Expanded(child: Container(margin: const EdgeInsets.all(4), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: accent.withOpacity(.09), borderRadius: BorderRadius.circular(19)), child: Column(children: [Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 10), Text(path?.toString() ?? '—', style: TextStyle(color: accent, fontSize: 43, fontWeight: FontWeight.w900)), const Text('Chỉ số đường đời', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800)), const SizedBox(height: 7), Text(path == null ? 'Thêm ngày sinh để xem diễn giải.' : numerologyMeaning[path] ?? 'Một con số để tự chiêm nghiệm.', textAlign: TextAlign.center, style: const TextStyle(fontSize: 10)), const Divider(height: 22), const Text('Năm cá nhân', style: TextStyle(fontSize: 9)), Text(year?.toString() ?? '—', style: TextStyle(color: accent, fontSize: 22, fontWeight: FontWeight.w900)), Text(year == null ? 'Chưa có dữ liệu' : 'Chủ đề: ${personalYearMeaning[year]}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 9))])));
  @override
  Widget build(BuildContext context) {
    final one = _life(parseDate(store.data['birthDateOne'])); final two = _life(parseDate(store.data['birthDateTwo'])); final y1 = _year(parseDate(store.data['birthDateOne'])); final y2 = _year(parseDate(store.data['birthDateTwo']));
    final a = _reduce(one, masters: false); final b = _reduce(two, masters: false); final score = a == null || b == null ? null : 100 - (a - b).abs() * 10;
    return PageShell(title: 'Thần số học đôi', subtitle: 'Những con số biểu tượng dựa trên ngày sinh của hai bạn.', accent: accent, children: [GlassCard(child: Column(children: [const Icon(Icons.auto_awesome_rounded, size: 30), const SizedBox(height: 8), const Text('Hai ngày sinh · Hai con số chủ đạo', style: TextStyle(fontWeight: FontWeight.w900)), const Text('Chỉ số đường đời và năm cá nhân chỉ mang tính tham khảo, giải trí.', textAlign: TextAlign.center, style: TextStyle(fontSize: 10))])), GlassCard(child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [_person((store.data['personOne'] ?? 'Mình').toString(), one, y1, accent), _person((store.data['personTwo'] ?? 'Người ấy').toString(), two, y2, accent)])), GlassCard(child: Column(children: [const Text('MỨC ĐỘ ĐỒNG ĐIỆU', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 10, letterSpacing: 1.5)), const SizedBox(height: 7), Text(score == null ? '— /100' : '$score/100', style: TextStyle(fontSize: 38, fontWeight: FontWeight.w900, color: accent)), LinearProgressIndicator(value: score == null ? 0 : score / 100, color: accent, minHeight: 7, backgroundColor: accent.withOpacity(.13)), const SizedBox(height: 9), Text(score == null ? 'Cần nhập ngày sinh của cả hai trong Cài đặt để tính chỉ số tham khảo.' : 'Hai con số biểu tượng là $one và $two. Đây không phải thang đo tình cảm hay dự đoán tương lai.', textAlign: TextAlign.center, style: const TextStyle(fontSize: 11)), const SizedBox(height: 7), OutlinedButton.icon(onPressed: () => store.notifyListeners(), icon: const Icon(Icons.refresh_rounded), label: const Text('Tính lại các con số'))])), GlassCard(child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('♡ Lưu ý nhỏ', style: TextStyle(fontWeight: FontWeight.w900)), SizedBox(height: 6), Text('Thần số học không phải phương pháp khoa học để dự đoán vận mệnh hay đo mức độ hợp nhau. Sự tôn trọng, giao tiếp và cách hai bạn đối xử với nhau quan trọng hơn mọi con số.', style: TextStyle(fontSize: 11))]))]);
  }
}

class _LockScreenPreview extends StatelessWidget {
  const _LockScreenPreview({required this.store, required this.accent});
  final DataStore store;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    const weekdays = ['Thứ Hai', 'Thứ Ba', 'Thứ Tư', 'Thứ Năm', 'Thứ Sáu', 'Thứ Bảy', 'Chủ Nhật'];
    final time = '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
    final start = parseDate(store.data['startDate']) ?? now;
    final days = currentDays(start, now);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [const Color(0xFF20172D), accent.withOpacity(.72), const Color(0xFF3B2947)],
        ),
      ),
      child: Column(
        children: [
          Text(time, style: const TextStyle(color: Colors.white, fontSize: 38, fontWeight: FontWeight.w300, letterSpacing: 1)),
          Text('${weekdays[now.weekday - 1]} · ${formatDate(now)}', style: const TextStyle(color: Colors.white70, fontSize: 11)),
          const SizedBox(height: 14),
          Container(
            width: 220,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
            decoration: BoxDecoration(color: Colors.white.withOpacity(.12), borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white.withOpacity(.2))),
            child: Column(
              children: [
                Icon(Icons.favorite_rounded, color: accent, size: 23),
                Text(formatNumber(days), style: const TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.w900)),
                const Text('NGÀY BÊN NHAU', style: TextStyle(color: Colors.white70, fontSize: 8, letterSpacing: 2, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text('${store.data['personOne']}  ♡  ${store.data['personTwo']}', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.favorite_rounded, color: accent, size: 18),
              const SizedBox(width: 8),
              Text('$days ngày bên nhau', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 11)),
            ],
          ),
        ],
      ),
    );
  }
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key, required this.store, required this.accent, required this.pickImage, required this.onNotify, required this.onTestNotify, required this.onExport, required this.onImport, required this.onClear});
  final DataStore store; final Color accent; final Future<String> Function({required String prefix}) pickImage; final VoidCallback onNotify, onTestNotify; final VoidCallback onExport; final ValueChanged<bool> onImport; final VoidCallback onClear;
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}
class _SettingsPageState extends State<SettingsPage> {
  late final TextEditingController one, two, start, birthOne, birthTwo;
  String genderOne = '', genderTwo = '';
  @override
  void initState() { super.initState(); _loadFields(); }
  void _loadFields() {
    final d = widget.store.data;
    one = TextEditingController(text: d['personOne'].toString()); two = TextEditingController(text: d['personTwo'].toString());
    start = TextEditingController(text: _pretty(d['startDate'])); birthOne = TextEditingController(text: _pretty(d['birthDateOne'])); birthTwo = TextEditingController(text: _pretty(d['birthDateTwo']));
    genderOne = d['genderOne'] ?? ''; genderTwo = d['genderTwo'] ?? '';
  }
  String _pretty(dynamic d) { final date = parseDate(d); return date == null ? '' : formatDate(date); }
  @override
  void dispose() { one.dispose(); two.dispose(); start.dispose(); birthOne.dispose(); birthTwo.dispose(); super.dispose(); }
  Future<void> _selectDate(TextEditingController c, {bool required = false}) async {
    final initial = parseDate(c.text) ?? DateTime.now(); final picked = await showDatePicker(context: context, initialDate: initial, firstDate: DateTime(1900), lastDate: DateTime.now());
    if (picked != null) c.text = formatDate(picked);
  }
  Future<void> _saveProfile() async {
    final s = parseDate(start.text), b1 = parseDate(birthOne.text), b2 = parseDate(birthTwo.text);
    if (s == null || s.isAfter(dateOnly(DateTime.now()))) { _message('Ngày bắt đầu chưa hợp lệ hoặc nằm trong tương lai.'); return; }
    if (birthOne.text.trim().isNotEmpty && (b1 == null || b1.isAfter(dateOnly(DateTime.now())))) { _message('Ngày sinh người thứ nhất chưa hợp lệ.'); return; }
    if (birthTwo.text.trim().isNotEmpty && (b2 == null || b2.isAfter(dateOnly(DateTime.now())))) { _message('Ngày sinh người thứ hai chưa hợp lệ.'); return; }
    widget.store.data.addAll({'personOne': one.text.trim().isEmpty ? 'Mình' : one.text.trim().substring(0, one.text.trim().length.clamp(0,24).toInt()), 'personTwo': two.text.trim().isEmpty ? 'Người ấy' : two.text.trim().substring(0, two.text.trim().length.clamp(0,24).toInt()), 'startDate': isoDate(s), 'birthDateOne': b1 == null ? '' : isoDate(b1), 'birthDateTwo': b2 == null ? '' : isoDate(b2), 'genderOne': genderOne, 'genderTwo': genderTwo});
    await widget.store.save(); _message('Đã lưu hồ sơ và ngày đặc biệt 💗');
  }
  void _message(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text), behavior: SnackBarBehavior.floating));
  Future<void> _pickAsset(String key) async {
    final path = await widget.pickImage(prefix: key);
    if (path.isNotEmpty) { widget.store.data[key] = path; await widget.store.save(); }
  }
  @override
  Widget build(BuildContext context) {
    final d = widget.store.data;
    return PageShell(title: 'Cài đặt', subtitle: 'Thiết lập hồ sơ, giao diện, thông báo và sao lưu dữ liệu.', accent: widget.accent, children: [
      GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const SectionTitle('Giao diện & màu sắc'), const Text('Bảng màu', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12)), const SizedBox(height: 9), Wrap(spacing: 9, runSpacing: 10, children: palettes.entries.map((e) => InkWell(onTap: () async { d['themePalette'] = e.key; await widget.store.save(); }, child: Column(children: [Container(width: 35, height: 35, decoration: BoxDecoration(color: e.value, shape: BoxShape.circle, border: Border.all(color: d['themePalette'] == e.key ? Theme.of(context).colorScheme.onSurface : Colors.transparent, width: 2))), Text({'rose':'Hồng mơ','lavender':'Lavender','ocean':'Đại dương','mint':'Bạc hà','sunset':'Hoàng hôn'}[e.key]!, style: const TextStyle(fontSize: 9))]))).toList()), const Divider(height: 25), SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Chế độ sáng / tối', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13)), subtitle: const Text('Áp dụng cho toàn bộ ứng dụng', style: TextStyle(fontSize: 10)), value: d['themeMode'] == 'dark', onChanged: (v) async { d['themeMode'] = v ? 'dark' : 'light'; d['themeModeChosen'] = true; await widget.store.save(); }), const Divider(height: 20), const Text('Cấu hình hiệu năng', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12)), const SizedBox(height: 8), SegmentedButton<String>(segments: const [ButtonSegment(value: 'low', label: Text('Thấp')), ButtonSegment(value: 'medium', label: Text('Vừa')), ButtonSegment(value: 'high', label: Text('Cao'))], selected: {d['performanceLevel'] as String}, onSelectionChanged: (s) async { d['performanceLevel'] = s.first; d['motionEnabled'] = s.first != 'low'; await widget.store.save(); }), const SizedBox(height: 6), Text({'low':'Tắt các hiệu ứng chuyển động để tiết kiệm tài nguyên.','medium':'Chuyển cảnh nhẹ và cân bằng.','high':'Bật đầy đủ chuyển cảnh và hiệu ứng giao diện.'}[d['performanceLevel']]!, style: const TextStyle(fontSize: 10)), const SizedBox(height: 7), Text('Ảnh nền được làm mờ nhẹ phía sau các màn hình.', style: TextStyle(fontSize: 10, color: Theme.of(context).textTheme.bodySmall?.color))])),
      GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const SectionTitle('Thông tin của chúng mình'), TextField(controller: one, maxLength: 24, decoration: const InputDecoration(labelText: 'Tên người thứ nhất')), TextField(controller: two, maxLength: 24, decoration: const InputDecoration(labelText: 'Tên người thứ hai')), const SizedBox(height: 8), Row(children: [Expanded(child: DropdownButtonFormField<String>(value: genderOne, decoration: const InputDecoration(labelText: 'Giới tính người 1'), items: const [DropdownMenuItem(value: '', child: Text('Chưa chọn')), DropdownMenuItem(value: 'Nam', child: Text('Nam')), DropdownMenuItem(value: 'Nữ', child: Text('Nữ')), DropdownMenuItem(value: 'Khác', child: Text('Khác'))], onChanged: (v) => setState(() => genderOne = v ?? ''))), const SizedBox(width: 10), Expanded(child: DropdownButtonFormField<String>(value: genderTwo, decoration: const InputDecoration(labelText: 'Giới tính người 2'), items: const [DropdownMenuItem(value: '', child: Text('Chưa chọn')), DropdownMenuItem(value: 'Nam', child: Text('Nam')), DropdownMenuItem(value: 'Nữ', child: Text('Nữ')), DropdownMenuItem(value: 'Khác', child: Text('Khác'))], onChanged: (v) => setState(() => genderTwo = v ?? '')))]), _dateField('Ngày bắt đầu bên nhau', start), _dateField('Ngày sinh người thứ nhất', birthOne), _dateField('Ngày sinh người thứ hai', birthTwo), const SizedBox(height: 8), _imageSetting('Ảnh đại diện người thứ nhất', 'avatarOne', '🧸'), _imageSetting('Ảnh đại diện người thứ hai', 'avatarTwo', '🐰'), _imageSetting('Ảnh nền riêng', 'background', '🌌'), const SizedBox(height: 12), FilledButton.icon(onPressed: _saveProfile, icon: const Icon(Icons.save_rounded), label: const Text('Lưu thay đổi'))])),
      GlassCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SectionTitle('Màn hình khóa & Widget'),
            _LockScreenPreview(store: widget.store, accent: widget.accent),
            const SizedBox(height: 8),
            const Text('Đây là bản xem trước trong ứng dụng. Widget hệ thống cho màn hình chính/màn hình khóa chưa được tích hợp ở bản chuyển đổi này.', style: TextStyle(fontSize: 10)),
          ],
        ),
      ),
      GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const SectionTitle('Thông báo kỷ niệm'), Text(d['notificationsEnabled'] == true ? 'Đã bật quyền thông báo trên thiết bị.' : 'Chưa bật quyền thông báo.', style: const TextStyle(fontSize: 11)), const SizedBox(height: 10), Wrap(spacing: 8, runSpacing: 8, children: [FilledButton.icon(onPressed: widget.onNotify, icon: const Icon(Icons.notifications_active_outlined), label: const Text('Bật thông báo')), OutlinedButton.icon(onPressed: widget.onTestNotify, icon: const Icon(Icons.notification_important_outlined), label: const Text('Gửi thử'))]), const SizedBox(height: 7), const Text('Nhắc sinh nhật và cột mốc được kiểm tra khi ứng dụng đang chạy hoặc được mở lại. Hạn chế chạy nền của từng hãng điện thoại có thể ảnh hưởng đến thông báo.', style: TextStyle(fontSize: 10))])),
      GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const SectionTitle('Sao lưu & khôi phục'), Text('Dữ liệu lưu riêng trên thiết bị. Bản sao lưu JSON bao gồm hồ sơ, chủ đề, ảnh đại diện, ảnh nền, kỷ niệm và album ảnh.', style: const TextStyle(fontSize: 11)), const SizedBox(height: 10), FilledButton.icon(onPressed: widget.onExport, icon: const Icon(Icons.file_upload_outlined), label: const Text('Xuất toàn bộ dữ liệu (.json)')), const SizedBox(height: 8), Wrap(spacing: 8, children: [OutlinedButton.icon(onPressed: () => widget.onImport(false), icon: const Icon(Icons.restore_rounded), label: const Text('Nhập & thay thế')), OutlinedButton.icon(onPressed: () => widget.onImport(true), icon: const Icon(Icons.merge_rounded), label: const Text('Gộp dữ liệu'))]), const SizedBox(height: 7), Text('${(d['memories'] as List).length} kỷ niệm · ${(d['photos'] as List).length} ảnh album', style: TextStyle(color: widget.accent, fontSize: 10, fontWeight: FontWeight.w800)), const Divider(height: 24), TextButton.icon(onPressed: widget.onClear, icon: const Icon(Icons.delete_forever_outlined, color: Colors.redAccent), label: const Text('Xóa toàn bộ dữ liệu trên thiết bị', style: TextStyle(color: Colors.redAccent))) ])),
      GlassCard(child: const Text('Our Days Native · bản chuyển đổi từ HTML V4.8. Dữ liệu của ứng dụng được lưu cục bộ; ứng dụng chưa tự đồng bộ qua Internet.', style: TextStyle(fontSize: 10)))
    ]);
  }
  Widget _dateField(String label, TextEditingController c) => Padding(padding: const EdgeInsets.only(top: 8), child: TextField(controller: c, keyboardType: TextInputType.datetime, decoration: InputDecoration(labelText: label, hintText: 'dd/mm/yyyy', suffixIcon: IconButton(icon: const Icon(Icons.calendar_month_rounded), onPressed: () => _selectDate(c)))));
  Widget _imageSetting(String label, String key, String fallback) => Padding(padding: const EdgeInsets.only(top: 8), child: Row(children: [SizedBox(width: 47, height: 47, child: ClipRRect(borderRadius: BorderRadius.circular(12), child: _AssetImage(store: widget.store, path: widget.store.data[key]?.toString() ?? '', fallback: fallback))), const SizedBox(width: 10), Expanded(child: Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700))), TextButton(onPressed: () => _pickAsset(key), child: const Text('Đổi ảnh')), if ((widget.store.data[key] ?? '').toString().isNotEmpty) IconButton(tooltip: 'Xóa ảnh', onPressed: () async { widget.store.data[key] = ''; await widget.store.save(); }, icon: const Icon(Icons.close_rounded))]));
}
