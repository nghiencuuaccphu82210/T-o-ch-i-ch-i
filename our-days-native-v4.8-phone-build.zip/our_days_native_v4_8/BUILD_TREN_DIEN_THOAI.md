# Build Our Days Native trên điện thoại Android (không cài Flutter trên điện thoại)

Cách này dùng GitHub Actions để biên dịch trên máy chủ Linux. Điện thoại chỉ cần trình duyệt và kết nối Internet.

## Tệp cần có

- `our-days-native-v4.8-phone-build.zip`: mã nguồn Flutter.
- `deployment/build-android.yml`: nội dung workflow để GitHub chạy build.

## A. Tạo repository trên GitHub

1. Mở https://github.com bằng trình duyệt trên điện thoại và đăng nhập.
2. Chọn **New repository**.
3. Đặt tên, ví dụ `our-days-native`.
4. Chọn **Private** để mã nguồn không công khai (hoặc Public nếu bạn chủ động muốn công khai).
5. Chọn **Create repository**.

Không tải tệp sao lưu JSON riêng tư hoặc ảnh cá nhân của ứng dụng lên repository. Chỉ tải mã nguồn ZIP.

## B. Tạo workflow

1. Trong repository, chọn **Add file → Create new file**.
2. Đặt tên tệp chính xác là `.github/workflows/build-android.yml`.
3. Mở tệp `deployment/build-android.yml` trong ZIP bằng trình đọc văn bản, sao chép toàn bộ nội dung rồi dán vào trình sửa trên GitHub.
4. Chọn **Commit changes** để lưu.

## C. Tải mã nguồn ZIP lên repository

1. Trở về trang chính repository.
2. Chọn **Add file → Upload files**.
3. Chọn `our-days-native-v4.8-phone-build.zip` từ thư mục Downloads trên điện thoại.
4. Chọn **Commit changes**.

Workflow sẽ tìm tệp ZIP ở thư mục gốc repository, giải nén, khởi tạo các tệp nền tảng, chạy phân tích Dart, kiểm thử và biên dịch APK.

## D. Chạy build và tải APK

1. Mở tab **Actions** của repository.
2. Chọn workflow **Build Our Days APK**.
3. Chọn **Run workflow → Run workflow**.
4. Mở lần chạy mới nhất. Đợi đến khi trạng thái thành công (dấu tích xanh).
5. Ở phần **Artifacts**, chọn `our-days-native-v4.8-apk` để tải về. GitHub đóng gói artifact thành một ZIP; giải nén ZIP đó để lấy `app-release.apk`.
6. Mở APK trên điện thoại và làm theo lời nhắc cài đặt của Android. Chỉ cài APK do workflow trong repository của bạn tạo ra.

GitHub lưu artifact theo thời hạn của workflow; cấu hình hiện tại giữ artifact 30 ngày. Hãy tải APK về máy trước khi hết hạn.

## E. Nếu build thất bại

1. Trong tab Actions, mở lần chạy có dấu X đỏ.
2. Mở bước đầu tiên bị lỗi và chụp ảnh phần thông báo lỗi cuối cùng.
3. Gửi ảnh đó cùng tên bước lỗi để kiểm tra. Không cần gửi mật khẩu, token, khóa ký ứng dụng hoặc tệp sao lưu riêng tư.

## Lưu ý quan trọng

- Android 8.1 có API 27; dự án đặt `minSdk 24`, nhưng phải thử APK thật trên thiết bị để xác nhận tương thích thực tế.
- Đây là APK release được build từ mã nguồn hiện tại; việc build thành công không thay thế kiểm thử giao diện/chức năng trên máy thật.
- Mỗi lần sửa mã: cập nhật ZIP trong repository, commit bản ZIP mới (giữ tên tệp `.zip` ở thư mục gốc), vào Actions và chạy lại workflow.
- iOS cần runner macOS và cấu hình ký ứng dụng của Apple. Workflow này chỉ tạo APK Android, không tạo IPA.
