# OUR DAYS · Native Flutter V4.8

Đây là **bộ mã nguồn Flutter Native** được chuyển từ bản HTML `our-days-v4.8.html`. Ứng dụng vẽ giao diện bằng Flutter, không nhúng trình duyệt và không dùng WebView.

> **Lưu ý về trạng thái:** Đây là dự án mã nguồn chuyển đổi, chưa phải APK/IPA đã biên dịch. Môi trường tạo tệp hiện tại không có Flutter SDK, Android SDK/Gradle hoặc Xcode nên không thể xác nhận build thành công tại đây. Dự án có kèm script tạo các tệp nền tảng còn thiếu trên máy đã cài Flutter.

## Những phần đã chuyển

- Trang mở đầu, màn hình tổng quan và thanh điều hướng 7 mục. Có bản xem trước giao diện màn hình khóa/widget trong Cài đặt.
- Bộ đếm ngày yêu, tiến trình 1 năm dạng trái tim/vòng tròn, chuyển trang tổng thời gian bằng thao tác vuốt ngang.
- Phép tính năm/tháng/ngày/giờ/phút/giây theo lịch, có xử lý năm nhuận và độ dài từng tháng.
- Hồ sơ hai người, giới tính, ngày sinh, tuổi và vòng đếm đến sinh nhật.
- Sự kiện sinh nhật và kỷ niệm ngày yêu.
- Danh sách kỷ niệm có ghi chú và ảnh.
- Album ảnh: thêm nhiều ảnh, chia sẻ, xóa, nhập/xuất album JSON.
- Thần số học dạng tham khảo/giải trí.
- Năm bảng màu, sáng/tối, mức hiệu năng thấp/vừa/cao, ảnh nền.
- Nhắc sinh nhật và cột mốc trong lúc ứng dụng hoạt động hoặc được mở lại.
- Sao lưu/khôi phục JSON bao gồm cả ảnh; hỗ trợ tệp sao lưu `our-days-backup` do HTML V4.8 xuất.
- Dữ liệu ứng dụng được lưu cục bộ; ảnh lưu thành tệp riêng trong thư mục riêng của ứng dụng.

Một số hiệu ứng CSS của HTML được dựng lại bằng hiệu ứng Flutter tương đương, không phải bản sao pixel-perfect. Phần thông báo hiện kiểm tra khi ứng dụng mở/đang chạy; chưa triển khai lịch nhắc nền đáng tin cậy khi hệ điều hành đóng ứng dụng.

## Cách chuyển dữ liệu từ HTML V4.8

1. Mở bản HTML V4.8 cũ.
2. Vào Cài đặt → Sao lưu/Khôi phục → **Xuất toàn bộ (.json)**.
3. Chép tệp `our-days-backup-....json` sang thiết bị sẽ cài bản Native.
4. Mở Our Days Native → Cài đặt → **Nhập & thay thế** → chọn tệp JSON vừa xuất.
5. Kiểm tra tên, ngày yêu, ảnh đại diện, hình nền, kỷ niệm và album ảnh.

Dữ liệu HTML lưu trong bộ nhớ trình duyệt không thể tự đọc trực tiếp từ ứng dụng Native độc lập. Vì vậy cần xuất JSON từ HTML trước lần chuyển đầu tiên. Không chọn “Nhập & thay thế” nếu chưa muốn thay dữ liệu đang có; có thể dùng “Gộp dữ liệu” để chỉ thêm kỷ niệm và ảnh.

## Yêu cầu để biên dịch

- Flutter **3.41.6 trở lên** và Dart 3.11 trở lên.
- Android: JDK 17, Android SDK/Build Tools tương thích với compile SDK 36.
- iOS: macOS, Xcode và bộ công cụ iOS; mức triển khai tối thiểu được đặt ở iOS 14 do phiên bản bộ chọn tệp hiện tại.
- Để cài bản Android lên Android 8.1, `minSdk` của dự án là 24 (Android 7.0 trở lên), nên API 27 của Android 8.1 nằm trên mức tối thiểu. Tương thích thực tế vẫn cần thử trên máy thật.

## Tạo các tệp Android/iOS còn thiếu

Mở Terminal tại thư mục dự án và chạy:

```bash
bash scripts/bootstrap-platforms.sh
```

Script dùng `flutter create` trong thư mục tạm để sinh Xcode project, Podfile, Gradle wrapper và `local.properties`; sau đó đưa các tệp nền tảng đó vào dự án. Cấu hình Gradle Kotlin DSL và `minSdk` đã có sẵn trong thư mục `android/` của dự án này.

Sau đó chạy:

```bash
flutter pub get
flutter analyze
flutter test
```

Các lệnh kiểm tra cần được chạy trên máy đã cài Flutter; bộ mã nguồn trong ZIP không thể tự xác nhận lỗi biên dịch nếu chưa chạy các lệnh đó.

## Biên dịch APK bằng điện thoại (không cần cài Flutter trên Android)

Nếu chỉ có điện thoại, dùng GitHub Actions để biên dịch trên máy chủ: xem `BUILD_TREN_DIEN_THOAI.md` và tệp `deployment/build-android.yml`. Tạo repository, thêm workflow ở đường dẫn `.github/workflows/build-android.yml`, tải ZIP mã nguồn vào thư mục gốc rồi chạy workflow trong tab Actions. Kết quả APK xuất hiện trong mục Artifacts. GitHub-hosted runner cung cấp môi trường Linux; mức sử dụng miễn phí phụ thuộc loại repository và gói tài khoản.

Workflow ghim Flutter 3.50.0 (bản stable tháng 11/2026) và Java 17. Không tải dữ liệu sao lưu, ảnh riêng tư hoặc thông tin bí mật vào repository công khai.

## Tạo APK Android

```bash
flutter build apk --release
```

APK dự kiến nằm tại:

```text
build/app/outputs/flutter-apk/app-release.apk
```

Chép APK đó sang điện thoại Android và cài đặt. Nếu muốn phát hành/cập nhật chính thức, cần giữ nguyên `applicationId` là `com.ourdays.app` và tăng `version` trong `pubspec.yaml` cho mỗi bản mới.

## Tạo IPA iOS

Chỉ thực hiện trên macOS có Xcode:

```bash
flutter build ipa --release
```

Cần thiết lập Apple signing/team trong Xcode trước khi cài lên iPhone hoặc phân phối. IPA chưa được tạo trong môi trường hiện tại.

## Cập nhật mã nguồn ở các lần sau

- Giữ nguyên `applicationId` Android `com.ourdays.app` và bundle identifier iOS `com.ourdays.app` để bản cập nhật nhận diện cùng ứng dụng.
- Thay các tệp mã nguồn đã chỉnh (`lib/`, `pubspec.yaml` và tệp nền tảng liên quan), rồi chạy `flutter pub get` và build lại.
- Tăng số build, ví dụ `4.8.1+49`, trong `pubspec.yaml` trước khi phát hành bản tiếp theo.
- Không xóa thư mục dữ liệu ứng dụng khi cập nhật; dữ liệu hồ sơ/ảnh đang lưu cục bộ sẽ tiếp tục tồn tại nếu giữ nguyên ID ứng dụng.

## Cấu trúc chính

```text
lib/
  main.dart          Giao diện và luồng ứng dụng Flutter
  data_store.dart    Lưu dữ liệu, ảnh, nhập/xuất JSON
  date_math.dart     Phép tính lịch, năm nhuận, sinh nhật
android/             Cấu hình Android và MainActivity
    
ios/                 Tệp Info.plist ban đầu; Xcode project được sinh bởi script
migration/           Bản HTML V4.8 gốc để đối chiếu
scripts/             Script sinh tệp nền tảng còn thiếu
test/                Kiểm thử phép tính lịch
```

## Trạng thái và điều chưa xác minh

- Đã tạo mã nguồn cho các luồng chính và bộ chuyển đổi sao lưu V4.8.
- Đã thêm các ca kiểm thử ngày tháng trong `test/date_math_test.dart`, nhưng chưa thể chạy chúng ở môi trường hiện tại.
- Chưa chạy `flutter analyze`, chưa chạy build Android/iOS và chưa thử giao diện trên ASUS Android 8.1.
- APK, IPA, icon thương hiệu hoàn chỉnh, widget hệ thống thật và nhắc nền đã lên lịch chưa được cung cấp trong ZIP này.
- Ứng dụng hiện lưu dữ liệu cục bộ, chưa đồng bộ tự động qua Dropbox/Internet.
