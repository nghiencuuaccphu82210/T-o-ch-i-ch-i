# Changelog

## 4.8.0+48 · Native migration draft
- Flutter UI rewrite; no WebView.
- Ported calendar-aware elapsed time and annual progress calculations.
- Added heart/circle progress shape, swipe-to-elapsed screen and birthday profiles.
- Added memories, photos, numerology, palette/theme and performance settings.
- Added local JSON backup/restore with base64 image migration from HTML V4.8.
- Added native image picker, system share sheet and local notification hooks.
- Added Android host configuration and a script to generate missing platform host scaffolding.
- Added date-calculation unit tests (not run in this environment).
