#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if ! command -v flutter >/dev/null 2>&1; then
  echo "Không tìm thấy Flutter. Hãy cài Flutter 3.41.6+ và chạy lại script." >&2
  exit 1
fi

TMP="$(mktemp -d)"
cleanup() { rm -rf "$TMP"; }
trap cleanup EXIT

# Generate a clean host project away from the user source so our Dart files stay untouched.
flutter create --no-pub --platforms=android,ios --org com.ourdays --project-name app "$TMP/platform_host"

# Supply the generated iOS/Xcode runner. The Flutter code in lib/ remains this project's code.
rm -rf "$ROOT/ios"
mkdir -p "$ROOT/ios"
cp -R "$TMP/platform_host/ios/." "$ROOT/ios/"

# Supply Gradle wrapper scripts and wrapper JAR, while preserving this project's Gradle settings.
cp "$TMP/platform_host/android/gradlew" "$ROOT/android/gradlew"
cp "$TMP/platform_host/android/gradlew.bat" "$ROOT/android/gradlew.bat"
mkdir -p "$ROOT/android/gradle/wrapper"
cp "$TMP/platform_host/android/gradle/wrapper/gradle-wrapper.jar" "$ROOT/android/gradle/wrapper/gradle-wrapper.jar"
if [[ -f "$TMP/platform_host/android/local.properties" ]]; then
  cp "$TMP/platform_host/android/local.properties" "$ROOT/android/local.properties"
fi
chmod +x "$ROOT/android/gradlew"

# Add the photo permission description and require iOS 14+ (file_picker Darwin requirement).
python3 "$ROOT/scripts/patch_ios_project.py" "$ROOT/ios"

cd "$ROOT"
flutter pub get

echo "Đã tạo Xcode project và Gradle wrapper. Tiếp theo chạy flutter analyze / flutter test."
