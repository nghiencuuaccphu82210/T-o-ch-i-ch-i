#!/usr/bin/env python3
"""Apply Our Days iOS deployment target and Photos permission to generated host files."""
from pathlib import Path
import plistlib
import sys
import re

root = Path(sys.argv[1])
plist_path = root / 'Runner' / 'Info.plist'
if plist_path.exists():
    with plist_path.open('rb') as stream:
        info = plistlib.load(stream)
    info['CFBundleDisplayName'] = 'Our Days'
    info['NSPhotoLibraryUsageDescription'] = (
        'Our Days cần quyền truy cập ảnh để lưu ảnh đại diện, ảnh nền và album kỷ niệm của bạn.'
    )
    with plist_path.open('wb') as stream:
        plistlib.dump(info, stream)

podfile = root / 'Podfile'
if podfile.exists():
    pod_text = podfile.read_text(encoding='utf-8')
    pod_text = re.sub(r"platform :ios, ['\"][^'\"]+['\"]", "platform :ios, '14.0'", pod_text)
    podfile.write_text(pod_text, encoding='utf-8')

project = root / 'Runner.xcodeproj' / 'project.pbxproj'
if project.exists():
    content = project.read_text(encoding='utf-8')
    content = re.sub(r'IPHONEOS_DEPLOYMENT_TARGET = [^;]+;', 'IPHONEOS_DEPLOYMENT_TARGET = 14.0;', content)
    content = content.replace('PRODUCT_BUNDLE_IDENTIFIER = com.ourdays.app;', 'PRODUCT_BUNDLE_IDENTIFIER = com.ourdays.app;')
    project.write_text(content, encoding='utf-8')
