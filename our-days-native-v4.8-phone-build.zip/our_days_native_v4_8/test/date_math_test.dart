import 'package:flutter_test/flutter_test.dart';
import 'package:our_days_native/date_math.dart';

void main() {
  group('Our Days calendar calculations', () {
    test('counts the start date as day one', () {
      expect(currentDays(DateTime(2024, 2, 29), DateTime(2024, 2, 29, 23, 59)), 1);
      expect(currentDays(DateTime(2024, 2, 29), DateTime(2024, 3, 1)), 2);
    });

    test('handles leap-year anniversaries and different month lengths', () {
      expect(addCalendarYears(DateTime(2024, 2, 29), 1), DateTime(2025, 2, 28));
      expect(addCalendarMonths(DateTime(2025, 1, 31), 1), DateTime(2025, 2, 28));
    });

    test('elapsed time is expressed as calendar years, months, days and clock time', () {
      final parts = elapsedCalendarParts(
        DateTime(2024, 1, 31, 10),
        DateTime(2024, 3, 1, 12, 34, 56),
      );
      expect(parts.years, 0);
      expect(parts.months, 1);
      expect(parts.days, 1);
      expect(parts.hours, 2);
      expect(parts.minutes, 34);
      expect(parts.seconds, 56);
    });

    test('birthday age and countdown are date-aware', () {
      final info = birthdayInfo(DateTime(2000, 2, 29), DateTime(2025, 2, 28))!;
      expect(info.age, 24);
      expect(info.remaining, 1);
      expect(info.nextDate, DateTime(2025, 3, 1));
    });

    test('calculates the next yearly special date', () {
      expect(nextRecurringDate(2, 14, DateTime(2026, 1, 1)), DateTime(2026, 2, 14));
      expect(nextRecurringDate(2, 14, DateTime(2026, 2, 14)), DateTime(2026, 2, 14));
      expect(nextRecurringDate(2, 14, DateTime(2026, 2, 15)), DateTime(2027, 2, 14));
    });

    test('rejects impossible manually entered dates', () {
      expect(parseDate('31/02/2025'), isNull);
      expect(parseDate('29/02/2024'), DateTime(2024, 2, 29));
      expect(parseDate('2024-02-29'), DateTime(2024, 2, 29));
    });
  });
}
